<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit;
}
include "koneksi.php";

$id_penyewa = intval($_SESSION['user_id']);

// Ambil motor tersedia beserta tarif & dokumen
$motor_res = $conn->query("
    SELECT m.id, m.merk, m.tipe_cc, m.plat_nomor, m.photo, m.dokumen_kepemilikan, m.status,
        MAX(CASE WHEN t.jenis='harian' THEN t.harga END) AS tarif_harian,
        MAX(CASE WHEN t.jenis='mingguan' THEN t.harga END) AS tarif_mingguan,
        MAX(CASE WHEN t.jenis='bulanan' THEN t.harga END) AS tarif_bulanan
    FROM motor m
    LEFT JOIN tarif t ON m.id=t.motor_id AND t.status='aktif'
    WHERE m.status='tersedia'
    GROUP BY m.id
    ORDER BY m.merk
");

// Fungsi untuk menampilkan foto motor dengan fallback
function motorPhoto($foto){
    $default = 'uploads_motor/default.jpg';
    if(!empty($foto) && file_exists('uploads_motor/'.basename($foto))){
        return 'uploads_motor/'.basename($foto);
    }
    return $default;
}

// Proses submit sewa
if (isset($_POST['submit'])) {
    $motor_id = (int)$_POST['motor_id'];
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tipe_durasi = $_POST['tipe_durasi'];

    $q_motor = $conn->query("
        SELECT m.id,
            MAX(CASE WHEN t.jenis='harian' THEN t.harga END) AS tarif_harian,
            MAX(CASE WHEN t.jenis='mingguan' THEN t.harga END) AS tarif_mingguan,
            MAX(CASE WHEN t.jenis='bulanan' THEN t.harga END) AS tarif_bulanan
        FROM motor m
        LEFT JOIN tarif t ON m.id=t.motor_id AND t.status='aktif'
        WHERE m.id='$motor_id'
        GROUP BY m.id
    ");
    $m_selected = $q_motor->fetch_assoc();
    if (!$m_selected) { echo "Tarif untuk motor ini belum tersedia!"; exit; }

    switch($tipe_durasi){
        case 'harian':
            $total = $m_selected['tarif_harian'];
            $tanggal_selesai = date('Y-m-d', strtotime($tanggal_mulai.' +1 day'));
            break;
        case 'mingguan':
            $total = $m_selected['tarif_mingguan'];
            $tanggal_selesai = date('Y-m-d', strtotime($tanggal_mulai.' +7 day'));
            break;
        case 'bulanan':
            $total = $m_selected['tarif_bulanan'];
            $tanggal_selesai = date('Y-m-d', strtotime($tanggal_mulai.' +30 day'));
            break;
        default:
            $total = 0;
            $tanggal_selesai = $tanggal_mulai;
    }

    // 1. Insert ke tabel sewa
    $sql = "INSERT INTO sewa (motor_id, penyewa_id, tanggal_mulai, tanggal_selesai, tipe_durasi, total_harga, status)
            VALUES ('$motor_id','$id_penyewa','$tanggal_mulai','$tanggal_selesai','$tipe_durasi','$total','menunggu_konfirmasi')";
    if (mysqli_query($conn, $sql)) {
        $id_sewa = mysqli_insert_id($conn);

        // 2. Insert ke tabel pembayaran dengan status pending
        $sql_bayar = "INSERT INTO pembayaran (sewa_id, jumlah, status, tanggal_bayar) 
                      VALUES ('$id_sewa','$total','Pending',NOW())";
        mysqli_query($conn, $sql_bayar);

        // 3. Motor masih "tersedia" sampai admin konfirmasi
        // Status motor baru jadi "disewa" setelah admin konfirmasi pembayaran

        header("Location: sewa_penyewa.php");
        exit;
    } else {
        echo "Error: ".mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Daftar Motor Tersedia</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { background:#f4f6f9; font-family:'Segoe UI', Tahoma, sans-serif; }
.card { border-radius:12px; transition:0.3s; }
.card:hover { transform:translateY(-5px); box-shadow:0 8px 20px rgba(0,0,0,0.2); }
.card img { height:180px; object-fit:cover; border-radius:12px 12px 0 0; width:100%; }
.card-title { font-weight:bold; font-size:18px; }
.badge-tarif { font-size:14px; margin-right:5px; margin-bottom:3px; display:inline-block; }
.btn-sewa { background:#2980b9; color:#fff; border:none; transition:0.3s; }
.btn-sewa:hover { background:#1f6391; }
</style>
</head>
<body>
<div class="container py-4">
    <h2 class="mb-4 text-center">Daftar Motor Tersedia</h2>
    <div class="row g-4">
        <?php while($m = $motor_res->fetch_assoc()): ?>
        <div class="col-md-4 col-sm-6">
            <div class="card h-100 shadow-sm d-flex flex-column">
                <img src="<?= motorPhoto($m['photo']) ?>" alt="Motor <?= htmlspecialchars($m['merk'].' '.$m['tipe_cc']) ?>">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?= htmlspecialchars($m['merk'].' '.$m['tipe_cc']) ?></h5>
                    <p><strong>Plat Nomor:</strong> <?= htmlspecialchars($m['plat_nomor']) ?></p>
                    <div class="mb-2">
                        <?php if($m['tarif_harian'] !== null): ?><span class="badge bg-primary badge-tarif">Harian: Rp <?= number_format($m['tarif_harian']) ?></span><?php endif; ?>
                        <?php if($m['tarif_mingguan'] !== null): ?><span class="badge bg-success badge-tarif">Mingguan: Rp <?= number_format($m['tarif_mingguan']) ?></span><?php endif; ?>
                        <?php if($m['tarif_bulanan'] !== null): ?><span class="badge bg-warning text-dark badge-tarif">Bulanan: Rp <?= number_format($m['tarif_bulanan']) ?></span><?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-outline-secondary mb-2" data-bs-toggle="modal" data-bs-target="#detailModal<?= $m['id'] ?>">
                        <i class="fa fa-eye"></i> Detail
                    </button>
                    <form method="post" class="mt-auto">
                        <input type="hidden" name="motor_id" value="<?= $m['id'] ?>">
                        <input type="date" name="tanggal_mulai" class="form-control mb-2" required>
                        <select name="tipe_durasi" class="form-select mb-2" required>
                            <option value="">-- Pilih Durasi --</option>
                            <option value="harian">Harian</option>
                            <option value="mingguan">Mingguan</option>
                            <option value="bulanan">Bulanan</option>
                        </select>
                        <button type="submit" name="submit" class="btn btn-sewa w-100"><i class="fa fa-motorcycle"></i> Sewa</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal Detail -->
        <div class="modal fade" id="detailModal<?= $m['id'] ?>" tabindex="-1" aria-labelledby="detailModalLabel<?= $m['id'] ?>" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel<?= $m['id'] ?>">Detail Motor <?= htmlspecialchars($m['merk'].' '.$m['tipe_cc']) ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <img src="<?= motorPhoto($m['photo']) ?>" alt="Motor" class="img-fluid mb-3" style="max-height:250px;">
                <p><strong>Merk:</strong> <?= htmlspecialchars($m['merk']) ?></p>
                <p><strong>Tipe CC:</strong> <?= htmlspecialchars($m['tipe_cc']) ?></p>
                <p><strong>Plat Nomor:</strong> <?= htmlspecialchars($m['plat_nomor']) ?></p>
                <p><strong>Status:</strong> <?= htmlspecialchars(ucfirst($m['status'])) ?></p>
                <p><strong>Tarif:</strong><br>
                    <?php if($m['tarif_harian'] !== null) echo "Harian: Rp ".number_format($m['tarif_harian'])."<br>"; ?>
                    <?php if($m['tarif_mingguan'] !== null) echo "Mingguan: Rp ".number_format($m['tarif_mingguan'])."<br>"; ?>
                    <?php if($m['tarif_bulanan'] !== null) echo "Bulanan: Rp ".number_format($m['tarif_bulanan'])."<br>"; ?>
                </p>
                <p><strong>Dokumen:</strong>
                    <?php if(!empty($m['dokumen_kepemilikan']) && file_exists('uploads_dokumen/'.$m['dokumen_kepemilikan'])): ?>
                        <a href="uploads_dokumen/<?= htmlspecialchars($m['dokumen_kepemilikan']) ?>" target="_blank"><i class="fa fa-file-pdf"></i> Lihat Dokumen</a>
                    <?php else: ?>
                        Tidak tersedia
                    <?php endif; ?>
                </p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
              </div>
            </div>
          </div>
        </div>

        <?php endwhile; ?>
    </div>
    <a href="dashboard_penyewa.php" class="btn btn-success mt-4"><i class="fa fa-arrow-left"></i> Kembali ke Dashboard</a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
