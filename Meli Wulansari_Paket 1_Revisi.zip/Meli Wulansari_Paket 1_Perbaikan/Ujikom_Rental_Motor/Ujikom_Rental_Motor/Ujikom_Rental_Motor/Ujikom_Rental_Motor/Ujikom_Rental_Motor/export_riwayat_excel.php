<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit;
}

$penyewa_id = $_SESSION['user_id'];

// Ambil data sewa
$sql = "SELECT s.id, m.merk, m.plat_nomor, s.tanggal_mulai, s.tanggal_selesai, s.tipe_durasi, s.status
        FROM sewa s
        JOIN motor m ON s.motor_id = m.id
        WHERE s.penyewa_id = ?
        ORDER BY s.id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $penyewa_id);
$stmt->execute();
$result = $stmt->get_result();

// Header untuk Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=riwayat_sewa.xls");

echo "Motor\tPlat Nomor\tTanggal Mulai\tTanggal Selesai\tTipe Durasi\tStatus\n";

while($row = $result->fetch_assoc()){
    $status = ($row['status']=='pending') ? 'Menunggu Verifikasi' :
              (($row['status']=='disetujui') ? 'Disetujui' : 
              (($row['status']=='ditolak') ? 'Ditolak' : $row['status']));
    echo "{$row['merk']}\t{$row['plat_nomor']}\t{$row['tanggal_mulai']}\t{$row['tanggal_selesai']}\t{$row['tipe_durasi']}\t$status\n";
}
exit;
?>
