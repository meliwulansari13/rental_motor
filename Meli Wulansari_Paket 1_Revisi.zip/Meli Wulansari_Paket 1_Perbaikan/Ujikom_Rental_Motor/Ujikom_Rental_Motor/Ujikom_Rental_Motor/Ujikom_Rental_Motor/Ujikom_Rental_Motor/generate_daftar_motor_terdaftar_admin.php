<?php
session_start();
include "koneksi.php";

// cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// query ambil data motor + pemilik + harga terbaru
$sql = "
SELECT m.id, m.merk, m.tipe_cc, u.nama AS pemilik,
       COALESCE(t.harga, m.harga_sewa) AS harga_terbaru,
       m.status
FROM motor m
LEFT JOIN users u ON m.pemilik_id = u.id
LEFT JOIN (
    SELECT motor_id, MAX(harga) AS harga
    FROM tarif
    WHERE status='aktif'
    GROUP BY motor_id
) t ON t.motor_id = m.id
ORDER BY m.id ASC
";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Motor Terdaftar - Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
    margin:0;
    font-family:'Segoe UI', Tahoma, sans-serif;
    background:#f4f6f9;
}

/* Sidebar */
.sidebar {
    width:240px;
    background:#111827;
    color:white;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    padding-top:20px;
    display:flex;
    flex-direction:column;
    overflow-y:auto;
}
.sidebar h2 {
    text-align:center;
    margin-bottom:20px;
    font-size:20px;
    font-weight:bold;
    letter-spacing:1px;
    color:white;
}
.sidebar a {
    display:block;
    color:#cfd8dc;
    padding:12px 20px;
    text-decoration:none;
    font-size:14px;
    border-left:4px solid transparent;
    transition:all 0.3s;
}
.sidebar a:hover,
.sidebar a.active {
    background:#1f2937;
    color:#fff;
    border-left:4px solid #2563eb;
}

/* Main */
.main {
    margin-left:240px;
    padding:20px;
    min-height:100vh;
}

/* Card */
.card {
    background:#fff;
    border-radius:12px;
    padding:20px;
    box-shadow:0 3px 8px rgba(0,0,0,0.1);
}

/* Table */
table {
    width:100%;
    border-collapse:collapse;
    margin-top:15px;
    background:#fff;
    border-radius:12px;
    overflow:hidden;
    box-shadow:0 2px 6px rgba(0,0,0,0.05);
}
th, td {
    padding:12px;
    text-align:center;
    border-bottom:1px solid #eee;
}
th {
    background:#34495e;
    color:white;
}
tr:nth-child(even) {background:#fafafa;}
tr:hover {background:#f1f1f1;}

/* Status badge */
.status {
    padding:6px 12px;
    border-radius:20px;
    font-size:13px;
    font-weight:bold;
}
.aktif {background:#f39c12;color:white;}
.selesai {background:#27ae60;color:white;}
.batal {background:#e74c3c;color:white;}

/* Tombol */
.btn-back {
    display:inline-block;
    padding:8px 14px;
    background:#27ae60;
    color:white;
    border-radius:6px;
    text-decoration:none;
    font-weight:bold;
    margin-bottom:15px;
    border:none;
    cursor:pointer;
    margin-right:5px;
}
.btn-back:hover {background:#1f8b4d;}

/* Print only */
@media print {
    .sidebar, .btn-back {display:none;}
    .main {margin:0; padding:0;}
    .card {box-shadow:none; border:none; padding:0;}
    h1, .print-header h3 {text-align:center; margin-bottom:20px;}
    table {width:100%; border-collapse:collapse;}
    th, td {border:1px solid #000; padding:8px;}
    th {background:#ddd; color:#000;}
    tr:nth-child(even){background:#fff;}
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-hourglass-half"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php" class="active"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
    <div class="card">
        <h1>Daftar Motor Terdaftar</h1>

        <!-- Tombol Export & Cetak -->
        <a href="export_motor_terdaftar_pdf.php" class="btn-back"><i class="fa fa-file-excel"></i> Export Pdf</a>
        <a href="export_motor_terdaftar_excel.php" class="btn-back"><i class="fa fa-file-excel"></i> Export Excel</a>
        <a href="#" class="btn-back" onclick="window.print(); return false;"><i class="fa fa-print"></i> Cetak</a>

        <!-- Header Laporan (hanya print) -->
        <div class="print-header">
            <h3>Laporan Daftar Motor Terdaftar</h3>
            <hr>
        </div>

        <div class="print-area">
            <table>
                <tr>
                    <th>No</th>
                    <th>Pemilik</th>
                    <th>Merk</th>
                    <th>Tipe/CC</th>
                    <th>Harga Sewa</th>
                    <th>Status</th>
                </tr>
                <?php
                $no = 1;
                if($result && $result->num_rows > 0):
                    while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($row['pemilik']); ?></td>
                    <td><?= htmlspecialchars($row['merk']); ?></td>
                    <td><?= htmlspecialchars($row['tipe_cc']); ?></td>
                    <td>Rp <?= number_format($row['harga_terbaru'],0,',','.'); ?></td>
                    <td><span class="status <?= strtolower($row['status']); ?>"><?= ucfirst($row['status']); ?></span></td>
                </tr>
                <?php endwhile; else: ?>
                <tr>
                    <td colspan="6">Belum ada motor terdaftar</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>

</body>
</html>
