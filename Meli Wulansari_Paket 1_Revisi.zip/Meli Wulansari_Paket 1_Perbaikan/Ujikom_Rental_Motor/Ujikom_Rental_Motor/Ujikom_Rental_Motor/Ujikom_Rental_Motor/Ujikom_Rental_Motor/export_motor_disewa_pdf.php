<?php
require('fpdf/fpdf.php');
include "koneksi.php";

// Ambil semua motor yang sedang disewa
$sql = "
SELECT s.id AS sewa_id, u.nama AS penyewa, m.merk, m.tipe_cc, m.plat_nomor,
       s.tanggal_mulai, s.tanggal_selesai, COALESCE(s.total_harga,0) AS total_biaya
FROM sewa s
JOIN motor m ON s.motor_id = m.id
JOIN users u ON s.penyewa_id = u.id
WHERE s.status_sewa='Disewa'
ORDER BY s.tanggal_mulai DESC
";
$result = $conn->query($sql);

// Inisialisasi PDF
$pdf = new FPDF('L','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Daftar Motor Sedang Disewa',0,1,'C');
$pdf->Ln(5);

// Header tabel
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(200,200,200);
$pdf->Cell(10,8,'No',1,0,'C',true);
$pdf->Cell(50,8,'Penyewa',1,0,'C',true);
$pdf->Cell(50,8,'Motor',1,0,'C',true);
$pdf->Cell(40,8,'Plat Nomor',1,0,'C',true);
$pdf->Cell(40,8,'Tgl Mulai',1,0,'C',true);
$pdf->Cell(40,8,'Tgl Selesai',1,0,'C',true);
$pdf->Cell(30,8,'Total (Rp)',1,1,'C',true);

// Isi tabel
$pdf->SetFont('Arial','',10);
$i = 1;
while($row = $result->fetch_assoc()){
    $pdf->Cell(10,8,$i++,1,0,'C');
    $pdf->Cell(50,8,$row['penyewa'],1,0);
    $pdf->Cell(50,8,$row['merk'].' '.$row['tipe_cc'],1,0);
    $pdf->Cell(40,8,$row['plat_nomor'],1,0,'C');
    $pdf->Cell(40,8,date('d-m-Y', strtotime($row['tanggal_mulai'])),1,0,'C');
    $pdf->Cell(40,8,date('d-m-Y', strtotime($row['tanggal_selesai'])),1,0,'C');
    $pdf->Cell(30,8,number_format($row['total_biaya'],0,',','.'),1,1,'R');
}

// Output PDF
$pdf->Output('D','motor_disewa.pdf');
