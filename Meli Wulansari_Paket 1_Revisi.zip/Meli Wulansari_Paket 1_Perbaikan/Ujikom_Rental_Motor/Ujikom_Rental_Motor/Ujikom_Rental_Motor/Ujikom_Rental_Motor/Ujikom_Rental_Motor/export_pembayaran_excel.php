<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil status dari URL
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'Pending';

// Query data pembayaran
$sql = "
SELECT 
    u.nama AS penyewa,
    m.merk,
    m.plat_nomor,
    pb.tanggal_bayar,
    COALESCE(
        (DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1) * 
        COALESCE(t.harga, m.harga_sewa, 0), 
        0
    ) AS jumlah,
    IF(pb.status IS NULL OR pb.status='', 'Pending', pb.status) AS status
FROM pembayaran pb
JOIN sewa s ON pb.sewa_id = s.id
JOIN users u ON s.penyewa_id = u.id
JOIN motor m ON s.motor_id = m.id
LEFT JOIN (
    SELECT motor_id, MAX(harga) AS harga
    FROM tarif
    WHERE status='aktif'
    GROUP BY motor_id
) t ON t.motor_id = m.id
WHERE IF(pb.status IS NULL OR pb.status='', 'Pending', pb.status) = ?
ORDER BY pb.tanggal_bayar ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $status_filter);
$stmt->execute();
$result = $stmt->get_result();

// Header file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Pembayaran_{$status_filter}.xls");
header("Pragma: no-cache");
header("Expires: 0");

echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Penyewa</th>
        <th>Motor</th>
        <th>Tanggal Bayar</th>
        <th>Jumlah (Rp)</th>
        <th>Status</th>
      </tr>";

if($result && $result->num_rows > 0) {
    $i = 1;
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$i++."</td>";
        echo "<td>".htmlspecialchars($row['penyewa'])."</td>";
        echo "<td>".htmlspecialchars($row['merk']." (".$row['plat_nomor'].")")."</td>";
        echo "<td>".htmlspecialchars($row['tanggal_bayar'])."</td>";
        echo "<td>".$row['jumlah']."</td>";
        echo "<td>".htmlspecialchars($row['status'])."</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6'>Tidak ada data pembayaran dengan status ".htmlspecialchars($status_filter)."</td></tr>";
}

echo "</table>";
exit;
?>
