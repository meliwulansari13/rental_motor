<?php
session_start();
include "koneksi.php";

// Cek login admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil filter periode (harian/mingguan/bulanan)
$periode = isset($_GET['periode']) ? $_GET['periode'] : 'harian';
$harga_per_hari_default = 100000;

// Ambil semua sewa + motor
$sql = "SELECT s.tanggal_mulai, s.tanggal_selesai, m.harga_sewa
        FROM sewa s
        JOIN motor m ON s.motor_id = m.id";
$result = mysqli_query($conn, $sql);

// Simpan data sementara
$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $start_date = strtotime($row['tanggal_mulai']);
    $end_date   = strtotime($row['tanggal_selesai']);
    $days = ($end_date - $start_date)/(60*60*24) + 1;

    $harga = isset($row['harga_sewa']) && $row['harga_sewa'] > 0 ? $row['harga_sewa'] : $harga_per_hari_default;

    // Hitung durasi sesuai periode
    if ($periode == 'harian') {
        $durasi = $days;
        $key = date("Y-m-d", $start_date);
    } elseif ($periode == 'mingguan') {
        $durasi = ceil($days / 7);
        $key = date("o-\WW", $start_date); // ISO week
    } else { // perbulan
        $durasi = ceil($days / 30);
        $key = date("Y-m", $start_date);
    }

    $total = $durasi * $harga;

    if (!isset($data[$key])) {
        $data[$key] = ['jumlah' => 0, 'total' => 0];
    }

    $data[$key]['jumlah']++;
    $data[$key]['total'] += $total;
}

// Siapkan array untuk Chart.js
$labels = [];
$jumlah_transaksi = [];
$total_pendapatan = [];

ksort($data);
foreach ($data as $key => $value) {
    if ($periode == 'harian') {
        $labels[] = date("d M Y", strtotime($key));
    } elseif ($periode == 'mingguan') {
        $labels[] = "Minggu " . date("W", strtotime($key));
    } else {
        $labels[] = date("F Y", strtotime($key . "-01"));
    }
    $jumlah_transaksi[] = $value['jumlah'];
    $total_pendapatan[] = $value['total'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Grafik Transaksi & Pendapatan</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
    margin: 0;
    font-family: 'Segoe UI', Tahoma, sans-serif;
    background: #f4f6f9;
}

/* Sidebar */
.sidebar {
    width: 240px; /* lebih lega */
    background: #111827;
    color: white;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    padding-top: 20px;
    display: flex;
    flex-direction: column;
    overflow-y: auto; /* biar bisa scroll kalau menu banyak */
}
.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 20px;
    color: white;
    font-weight: bold;
    letter-spacing: 1px;
}
.sidebar a {
    display: block;
    color: #cfd8dc;
    padding: 12px 20px;
    text-decoration: none;
    font-size: 14px;
    border-left: 4px solid transparent;
    transition: all 0.3s;
}
.sidebar a:hover,
.sidebar a.active {
    background: #1f2937;
    color: #fff;
    border-left: 4px solid #2563eb;
}

/* Main content */
.main {
    margin-left: 240px; /* menyesuaikan dengan sidebar */
    padding: 20px;
    min-height: 100vh;
}

/* Card */
.card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    max-width: 1000px;
    margin: auto;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

/* Filter buttons */
.filter {
    text-align: center;
    margin-bottom: 20px;
}
.filter a {
    text-decoration: none;
    margin: 0 5px;
    padding: 8px 14px;
    border-radius: 6px;
    background: #3498db;
    color: white;
    font-weight: bold;
    transition: background 0.2s;
}
.filter a:hover {
    background: #217dbb;
}

</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-undo"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php" class="active"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>


<div class="main">
<div class="card">
<h2 style="text-align:center;">📊 Grafik Transaksi & Pendapatan per <?= ucfirst($periode) ?></h2>
<div class="filter">
<a href="?periode=harian">Per Hari</a>
<a href="?periode=mingguan">Per Minggu</a>
<a href="?periode=bulanan">Per Bulan</a>
</div>
<canvas id="myChart" height="100"></canvas>
</div>
</div>

<script>
const ctx = document.getElementById('myChart');
new Chart(ctx,{
    type:'bar',
    data:{
        labels: <?= json_encode($labels) ?>,
        datasets:[
            {
                label:'Jumlah Transaksi',
                data: <?= json_encode($jumlah_transaksi) ?>,
                backgroundColor:'rgba(52, 152, 219, 0.6)',
                borderColor:'rgba(41, 128, 185, 1)',
                borderWidth:1,
                yAxisID:'y1'
            },
            {
                label:'Total Pendapatan (Rp)',
                data: <?= json_encode($total_pendapatan) ?>,
                backgroundColor:'rgba(46, 204, 113, 0.6)',
                borderColor:'rgba(39, 174, 96, 1)',
                borderWidth:1,
                yAxisID:'y2'
            }
        ]
    },
    options:{
        responsive:true,
        interaction:{mode:'index',intersect:false},
        plugins:{
            tooltip:{
                callbacks:{
                    label:function(context){
                        if(context.dataset.label==='Total Pendapatan (Rp)'){
                            return context.dataset.label+': Rp '+context.raw.toLocaleString('id-ID');
                        }
                        return context.dataset.label+': '+context.raw;
                    }
                }
            }
        },
        scales:{
            y1:{type:'linear',position:'left',beginAtZero:true,title:{display:true,text:'Jumlah Transaksi'}},
            y2:{type:'linear',position:'right',beginAtZero:true,title:{display:true,text:'Total Pendapatan (Rp)'},grid:{drawOnChartArea:false}}
        }
    }
});
</script>

</body>
</html>
