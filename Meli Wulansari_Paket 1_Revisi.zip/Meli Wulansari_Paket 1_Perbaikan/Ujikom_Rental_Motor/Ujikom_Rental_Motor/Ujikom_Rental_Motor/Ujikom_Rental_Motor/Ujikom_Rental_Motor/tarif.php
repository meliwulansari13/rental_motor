<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil parameter pencarian
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Pesan sukses
$msg = '';
if (isset($_SESSION['msg'])) {
    $msg = $_SESSION['msg'];
    unset($_SESSION['msg']);
}

// Dropdown motor
$motor = $conn->query("SELECT * FROM motor ORDER BY merk, plat_nomor");

// Simpan / update tarif
if (isset($_POST['simpan'])) {
    $motor_id = (int)($_POST['motor_id'] ?? 0);
    $harian   = (int)($_POST['harian'] ?? 0);
    $mingguan = (int)($_POST['mingguan'] ?? 0);
    $bulanan  = (int)($_POST['bulanan'] ?? 0);

    if ($motor_id > 0) {
        $stmt_del = $conn->prepare("DELETE FROM tarif WHERE motor_id = ?");
        $stmt_del->bind_param("i", $motor_id);
        $stmt_del->execute();
        $stmt_del->close();

        $stmt_ins = $conn->prepare("INSERT INTO tarif (motor_id, jenis, harga, status) VALUES (?, ?, ?, 'aktif')");
        if ($stmt_ins) {
            foreach (['harian'=>$harian,'mingguan'=>$mingguan,'bulanan'=>$bulanan] as $jenis=>$harga){
                $stmt_ins->bind_param("isi", $motor_id, $jenis, $harga);
                $stmt_ins->execute();
            }
            $stmt_ins->close();
        }

        $_SESSION['msg'] = "Tarif motor berhasil diperbarui!";
    } else {
        $_SESSION['msg'] = "Pilih motor yang valid.";
    }

    header("Location: tarif.php?search=".urlencode($search));
    exit();
}

// Aksi hapus / nonaktif / aktif
if (isset($_GET['hapus_motor_id'])) {
    $id = (int)$_GET['hapus_motor_id'];
    $stmt = $conn->prepare("DELETE FROM tarif WHERE motor_id = ?");
    $stmt->bind_param("i", $id); $stmt->execute(); $stmt->close();
    $_SESSION['msg'] = "Tarif motor berhasil dihapus!";
    header("Location: tarif.php?search=".urlencode($search)); exit();
}
if (isset($_GET['nonaktif_motor_id'])) {
    $id = (int)$_GET['nonaktif_motor_id'];
    $stmt = $conn->prepare("UPDATE tarif SET status='nonaktif' WHERE motor_id = ?");
    $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
    $_SESSION['msg']="Tarif motor berhasil dinonaktifkan!";
    header("Location: tarif.php?search=".urlencode($search)); exit();
}
if (isset($_GET['aktif_motor_id'])) {
    $id = (int)$_GET['aktif_motor_id'];
    $stmt = $conn->prepare("UPDATE tarif SET status='aktif' WHERE motor_id = ?");
    $stmt->bind_param("i",$id); $stmt->execute(); $stmt->close();
    $_SESSION['msg']="Tarif motor berhasil diaktifkan!";
    header("Location: tarif.php?search=".urlencode($search)); exit();
}

// Ambil data tarif
if ($search!=='') {
    $like="%{$search}%";
    $sql = "SELECT m.id AS motor_id, m.merk, m.tipe_cc, m.plat_nomor,
        MAX(CASE WHEN t.jenis='harian' THEN t.harga END) AS harian,
        MAX(CASE WHEN t.jenis='mingguan' THEN t.harga END) AS mingguan,
        MAX(CASE WHEN t.jenis='bulanan' THEN t.harga END) AS bulanan,
        MAX(t.status) AS status
        FROM motor m
        LEFT JOIN tarif t ON m.id = t.motor_id
        WHERE m.merk LIKE ? OR m.plat_nomor LIKE ? OR m.tipe_cc LIKE ?
        GROUP BY m.id
        ORDER BY m.merk, m.plat_nomor";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("sss",$like,$like,$like);
    $stmt->execute();
    $res=$stmt->get_result();
    $stmt->close();
} else {
    $sql = "SELECT m.id AS motor_id, m.merk, m.tipe_cc, m.plat_nomor,
        MAX(CASE WHEN t.jenis='harian' THEN t.harga END) AS harian,
        MAX(CASE WHEN t.jenis='mingguan' THEN t.harga END) AS mingguan,
        MAX(CASE WHEN t.jenis='bulanan' THEN t.harga END) AS bulanan,
        MAX(t.status) AS status
        FROM motor m
        LEFT JOIN tarif t ON m.id = t.motor_id
        GROUP BY m.id
        ORDER BY m.merk, m.plat_nomor";
    $res = $conn->query($sql);
}

// Edit data
$edit_motor_id = isset($_GET['edit_motor_id'])?(int)$_GET['edit_motor_id']:0;
$edit_data=null;
if ($edit_motor_id){
    $tarif_stmt=$conn->prepare("SELECT jenis,harga FROM tarif WHERE motor_id=?");
    $tarif_stmt->bind_param("i",$edit_motor_id); $tarif_stmt->execute();
    $tarif_result=$tarif_stmt->get_result();
    $tarif_arr=['harian'=>'','mingguan'=>'','bulanan'=>''];
    while($rowt=$tarif_result->fetch_assoc()) $tarif_arr[$rowt['jenis']]=$rowt['harga'];
    $tarif_stmt->close();

    $motor_stmt=$conn->prepare("SELECT * FROM motor WHERE id=?");
    $motor_stmt->bind_param("i",$edit_motor_id); $motor_stmt->execute();
    $motor_data=$motor_stmt->get_result()->fetch_assoc()?:[];
    $motor_stmt->close();

    $edit_data=[
        'motor_id'=>$edit_motor_id,
        'merk'=>$motor_data['merk']??'',
        'tipe_cc'=>$motor_data['tipe_cc']??'',
        'plat_nomor'=>$motor_data['plat_nomor']??'',
        'harian'=>$tarif_arr['harian'],
        'mingguan'=>$tarif_arr['mingguan'],
        'bulanan'=>$tarif_arr['bulanan']
    ];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tarif Rental Motor</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:#f4f6f9;
}

/* SIDEBAR */
.sidebar {
    width:240px; /* sedikit lebih lebar */
    background:#111827;
    color:#fff;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    display:flex;
    flex-direction:column;
    overflow-y:auto; /* scroll jika panjang */
}
.sidebar h2 {
    text-align:center;
    padding:22px 10px; /* sedikit lebih besar */
    margin:0;
    font-size:22px; /* lebih besar */
    background:#1f2937;
    color:#fff;
    border-bottom:2px solid #2563eb;
}
.sidebar a {
    display:block;
    padding:16px 22px; /* lebih nyaman */
    color:#cfd8dc;
    text-decoration:none;
    font-size:15px; /* sedikit lebih besar */
    border-left:4px solid transparent;
    transition:0.3s;
}
.sidebar a:hover,
.sidebar a.active {
    background:#1f2937;
    color:#fff;
    border-left:4px solid #2563eb;
}

/* MAIN CONTENT */
.main {
    margin-left:240px; /* sesuaikan dengan lebar sidebar */
    padding:24px;
}
.container {
    background:#fff;
    padding:22px;
    border-radius:12px;
    box-shadow:0 3px 14px rgba(0,0,0,0.08);
}
.header-row {
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:12px;
    flex-wrap:wrap;
}
h2 {
    margin:0;
    color:#2c3e50;
    font-size:22px; /* lebih besar */
}
.controls {
    display:flex;
    gap:12px;
    align-items:center;
}
.search-box input {
    padding:10px 14px;
    border:1px solid #d1d5db;
    border-radius:10px;
    width:280px; /* lebih luas */
    font-size:15px;
}
.search-box button {
    padding:10px 14px;
    border:none;
    border-radius:10px;
    background:#2563eb;
    color:#fff;
    cursor:pointer;
    font-size:15px;
}
.msg {
    text-align:center;
    margin:14px 0;
    font-weight:600;
    color:green;
}
form label {
    font-weight:600;
    font-size:15px;
}
input[type=number], select {
    padding:10px;
    border:1px solid #d1d5db;
    border-radius:10px;
    width:100%;
    font-size:15px;
}
button, .btn {
    padding:10px 16px;
    border:none;
    border-radius:10px;
    cursor:pointer;
    font-size:15px;
}

/* TABEL */
.table {
    width:100%;
    border-collapse:collapse;
    margin-top:18px;
    border-radius:10px;
    overflow:hidden;
    background:#fff;
}
th, td {
    padding:12px;
    border-bottom:1px solid #eee;
    text-align:center;
    font-size:15px;
}
th {
    background:#111827;
    color:#fff;
    text-transform:uppercase;
    font-size:14px;
}
tr:nth-child(even) {background:#fbfdff;}
.action-btns a {
    margin:0 4px;
    padding:8px 12px;
    border-radius:8px;
    text-decoration:none;
    font-size:14px;
    display:inline-block;
}

/* PAGINATION */
.pagination {
    display:flex;
    gap:10px;
    justify-content:center;
    align-items:center;
    margin-top:16px;
}
.page-link {
    padding:10px 14px;
    border-radius:10px;
    background:#fff;
    border:1px solid #e5e7eb;
    color:#111827;
    text-decoration:none;
    font-size:14px;
}
.page-link.disabled {opacity:0.6;pointer-events:none;}
.page-link.active {background:#2563eb;color:#fff;border-color:#2563eb;}
.small-note {color:#6b7280;font-size:14px;margin-top:10px;}
button[name="simpan"] {
    background:#2563eb;
    color:#fff;
    font-weight:600;
    border:none;
    border-radius:10px;
    padding:10px 16px;
    cursor:pointer;
    transition:0.3s;
}
button[name="simpan"]:hover {
    background:#1d4ed8;
}

/* Tombol aksi di tabel */
.action-btns a {
    margin:0 4px;
    padding:8px 12px;
    border-radius:8px;
    text-decoration:none;
    font-size:14px;
    display:inline-block;
    font-weight:600; /* tebal */
    transition:0.3s;
}
.action-btns a.btn-edit {
    background:#2563eb; color:#fff;
}
.action-btns a.btn-edit:hover { background:#1d4ed8; }

.action-btns a.btn-hapus {
    background:#dc2626; color:#fff;
}
.action-btns a.btn-hapus:hover { background:#b91c1c; }

.action-btns a.btn-nonaktif {
    background:#f97316; color:#fff;
}
.action-btns a.btn-nonaktif:hover { background:#c2410c; }

.action-btns a.btn-aktif {
    background:#16a34a; color:#fff;
}
.action-btns a.btn-aktif:hover { background:#15803d; }
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
    <a href="motor_tersedia.php"><i class="fa fa-hourglass-half"></i> Motor Tersedia</a>
    <a href="tarif.php" class="active"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>
<div class="main">
  <div class="container">
    <div class="header-row">
      <h2>⚙️ Tarif Motor</h2>
    </div>

    <!-- Form Tambah / Edit Tarif -->
    <form method="post" action="tarif_proses.php">
      <div style="display:flex;gap:12px;flex-wrap:wrap;">
        <div style="flex:1;min-width:220px;">
          <label>Pilih Motor</label>
          <select name="motor_id" required>
            <option value="">-- Pilih Motor --</option>
            <?php
            include "koneksi.php";
            $motor = $conn->query("SELECT * FROM motor ORDER BY merk, plat_nomor");
            while ($m = $motor->fetch_assoc()) {
              echo "<option value='".$m['id']."'>".$m['merk']." - ".$m['plat_nomor']."</option>";
            }
            ?>
          </select>
        </div>
        <div style="flex:1;min-width:160px;">
          <label>Tarif Harian</label>
          <input type="number" name="harian" min="0" required>
        </div>
        <div style="flex:1;min-width:160px;">
          <label>Tarif Mingguan</label>
          <input type="number" name="mingguan" min="0" required>
        </div>
        <div style="flex:1;min-width:160px;">
          <label>Tarif Bulanan</label>
          <input type="number" name="bulanan" min="0" required>
        </div>
        <div style="display:flex;align-items:flex-end;">
          <button type="submit" name="simpan">Tambah Tarif</button>
        </div>
      </div>
    </form>

    <!-- Tabel Tarif Motor -->
    <h3 style="margin-top:18px;">📊 Daftar Tarif Motor</h3>
    <div style="overflow-x:auto;">
      <table class="table">
        <thead>
          <tr>
            <th>No</th>
            <th>Motor</th>
            <th>Plat</th>
            <th>Tarif Harian</th>
            <th>Tarif Mingguan</th>
            <th>Tarif Bulanan</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT m.id, m.merk, m.tipe_cc, m.plat_nomor,
                       MAX(CASE WHEN t.jenis='harian' THEN t.harga END) AS harian,
                       MAX(CASE WHEN t.jenis='mingguan' THEN t.harga END) AS mingguan,
                       MAX(CASE WHEN t.jenis='bulanan' THEN t.harga END) AS bulanan
                FROM motor m
                LEFT JOIN tarif t ON m.id = t.motor_id
                GROUP BY m.id
                ORDER BY m.merk, m.plat_nomor";
        $res = $conn->query($sql);
        $i=1;
        if ($res->num_rows > 0) {
          while($row = $res->fetch_assoc()) {
            echo "<tr>
              <td>".$i++."</td>
              <td>".$row['merk']." ".$row['tipe_cc']."</td>
              <td>".$row['plat_nomor']."</td>
              <td>".($row['harian'] ? "Rp ".number_format($row['harian'],0,',','.') : "-")."</td>
              <td>".($row['mingguan'] ? "Rp ".number_format($row['mingguan'],0,',','.') : "-")."</td>
              <td>".($row['bulanan'] ? "Rp ".number_format($row['bulanan'],0,',','.') : "-")."</td>
              <td class='action-btns'>
                <a href='tarif_edit.php?id=".$row['id']."' class='btn-edit'>Edit</a>
                <a href='tarif_delete.php?id=".$row['id']."' class='btn-hapus' onclick=\"return confirm('Yakin hapus tarif motor ini?');\">Hapus</a>
              </td>
            </tr>";
          }
        } else {
          echo "<tr><td colspan='7'>Belum ada data tarif</td></tr>";
        }
        ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

</body>
</html>
