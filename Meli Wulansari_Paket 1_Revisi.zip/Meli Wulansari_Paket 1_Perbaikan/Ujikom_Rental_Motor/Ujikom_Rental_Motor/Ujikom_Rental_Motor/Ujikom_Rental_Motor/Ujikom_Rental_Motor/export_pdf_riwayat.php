<?php
require('fpdf/fpdf.php');
include "koneksi.php";

// Ambil semua data sewa
$sql = "SELECT s.id, u.nama AS penyewa, m.merk, m.tipe_cc, m.plat_nomor, 
               s.tanggal_mulai, s.tanggal_selesai, COALESCE(s.total_harga,0) AS total_biaya
        FROM sewa s
        JOIN users u ON s.penyewa_id = u.id
        JOIN motor m ON s.motor_id = m.id
        ORDER BY s.id DESC";
$result = $conn->query($sql);

// Inisialisasi PDF
$pdf = new FPDF('L','mm','A4'); // L = Landscape
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Riwayat Penyewaan Rental Motor',0,1,'C');
$pdf->Ln(5);

// Header tabel
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(200,200,200);
$pdf->Cell(10,8,'No',1,0,'C',true);
$pdf->Cell(50,8,'Penyewa',1,0,'C',true);
$pdf->Cell(60,8,'Motor',1,0,'C',true);
$pdf->Cell(30,8,'Tgl Mulai',1,0,'C',true);
$pdf->Cell(30,8,'Tgl Kembali',1,0,'C',true);
$pdf->Cell(30,8,'Total (Rp)',1,1,'C',true);

// Isi tabel
$pdf->SetFont('Arial','',10);
$i = 1;
$grand_total = 0;

while($row = $result->fetch_assoc()){
    $pdf->Cell(10,8,$i++,1,0,'C');
    $pdf->Cell(50,8,$row['penyewa'],1,0);
    $pdf->Cell(60,8,$row['merk'].' '.$row['tipe_cc'].' / '.$row['plat_nomor'],1,0);
    $pdf->Cell(30,8,date('d-m-Y', strtotime($row['tanggal_mulai'])),1,0,'C');
    $pdf->Cell(30,8,date('d-m-Y', strtotime($row['tanggal_selesai'])),1,0,'C');
    $pdf->Cell(30,8,number_format($row['total_biaya'],0,',','.'),1,1,'R');
    $grand_total += $row['total_biaya'];
}

// Total keseluruhan
$pdf->SetFont('Arial','B',10);
$pdf->Cell(180,8,'Total Keseluruhan',1,0,'R',true);
$pdf->Cell(30,8,number_format($grand_total,0,',','.'),1,1,'R',true);

// Output PDF
$pdf->Output('D','riwayat_penyewaan.pdf');
