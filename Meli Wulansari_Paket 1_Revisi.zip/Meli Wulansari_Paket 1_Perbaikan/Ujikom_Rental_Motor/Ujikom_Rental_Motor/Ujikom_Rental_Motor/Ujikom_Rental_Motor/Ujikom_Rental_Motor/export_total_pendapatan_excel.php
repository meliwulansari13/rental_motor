<?php
session_start();
include "koneksi.php";

// cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil filter periode dari URL
$periode = isset($_GET['periode']) ? $_GET['periode'] : 'bulan';

// Query total pendapatan berdasarkan periode
if ($periode == 'hari') {
    $sql = "SELECT DATE(tanggal_bayar) AS periode, SUM(jumlah) AS total
            FROM pembayaran
            GROUP BY DATE(tanggal_bayar)
            ORDER BY DATE(tanggal_bayar) DESC";
} elseif ($periode == 'minggu') {
    $sql = "SELECT YEAR(tanggal_bayar) AS tahun, WEEK(tanggal_bayar,1) AS minggu, SUM(jumlah) AS total
            FROM pembayaran
            GROUP BY YEAR(tanggal_bayar), WEEK(tanggal_bayar,1)
            ORDER BY YEAR(tanggal_bayar) DESC, WEEK(tanggal_bayar,1) DESC";
} elseif ($periode == 'tahun') {
    $sql = "SELECT YEAR(tanggal_bayar) AS periode, SUM(jumlah) AS total
            FROM pembayaran
            GROUP BY YEAR(tanggal_bayar)
            ORDER BY YEAR(tanggal_bayar) DESC";
} else { // bulan
    $sql = "SELECT DATE_FORMAT(tanggal_bayar, '%Y-%m') AS periode, SUM(jumlah) AS total
            FROM pembayaran
            GROUP BY DATE_FORMAT(tanggal_bayar, '%Y-%m')
            ORDER BY DATE_FORMAT(tanggal_bayar, '%Y-%m') DESC";
}

$result = $conn->query($sql);

// Header untuk export ke Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=total_pendapatan_{$periode}.xls");

// Mulai tabel Excel
echo "<table border='1'>";
echo "<tr>";
echo "<th>No</th>";
echo "<th>Periode</th>";
echo "<th>Total Pendapatan (Rp)</th>";
echo "</tr>";

if ($result && $result->num_rows > 0) {
    $i = 1;
    while ($row = $result->fetch_assoc()) {
        if ($periode == 'minggu') {
            $label = "Tahun " . $row['tahun'] . " - Minggu " . $row['minggu'];
        } else {
            $label = $row['periode'];
        }
        echo "<tr>";
        echo "<td>{$i}</td>";
        echo "<td>{$label}</td>";
        echo "<td>" . number_format($row['total'],0,',','.') . "</td>";
        echo "</tr>";
        $i++;
    }
} else {
    echo "<tr><td colspan='3'>Belum ada data pembayaran.</td></tr>";
}

echo "</table>";
exit;
