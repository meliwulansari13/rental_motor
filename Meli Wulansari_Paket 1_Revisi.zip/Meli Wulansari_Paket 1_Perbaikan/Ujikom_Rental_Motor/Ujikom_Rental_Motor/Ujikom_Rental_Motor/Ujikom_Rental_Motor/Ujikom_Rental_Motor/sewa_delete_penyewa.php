<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php"); exit;
}
include "koneksi.php";

$id = $_GET['id'];
$id_penyewa = $_SESSION['user_id'];
$sewa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM sewa WHERE id='$id' AND penyewa_id='$id_penyewa'"));

if ($sewa) {
    mysqli_query($conn, "UPDATE motor SET status='tersedia' WHERE id='{$sewa['motor_id']}'");
    mysqli_query($conn, "DELETE FROM sewa WHERE id='$id'");
}

header("Location: sewa_penyewa.php");
exit;