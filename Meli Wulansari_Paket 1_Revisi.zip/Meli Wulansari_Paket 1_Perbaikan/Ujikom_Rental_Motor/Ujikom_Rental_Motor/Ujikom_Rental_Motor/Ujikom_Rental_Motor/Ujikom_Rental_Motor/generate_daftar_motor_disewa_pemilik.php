<?php
session_start();
include "koneksi.php";

// Cek login & role pemilik
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

$id_pemilik = $_SESSION['user_id'];

// Query motor disewa milik pemilik ini
$sql = "SELECT s.id, u.nama AS penyewa,
               CONCAT(m.merk, ' ', m.tipe_cc) AS motor,
               m.photo,
               s.tanggal_mulai, s.tanggal_selesai, s.status
        FROM sewa s
        JOIN users u ON s.penyewa_id = u.id
        JOIN motor m ON s.motor_id = m.id
        WHERE m.pemilik_id = ?
        ORDER BY s.id DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_pemilik);
$stmt->execute();
$result = $stmt->get_result();

// fungsi badge status fleksibel
function badgeStatus($status){
    $s = strtolower(trim($status));
    
    // Warna sesuai status umum
    $colors = [
        'aktif'   => '#f39c12', // kuning/orange
        'selesai' => '#27ae60', // hijau
        'batal'   => '#e74c3c'  // merah
    ];

    // Ikon sesuai status umum
    $icons = [
        'aktif'   => '<i class="fa fa-clock"></i> ',
        'selesai' => '<i class="fa fa-check"></i> ',
        'batal'   => '<i class="fa fa-times"></i> '
    ];

    // Jika status ada di array, pakai warna & ikon khusus
    $color = $colors[$s] ?? '#7f8c8d'; // default abu-abu
    $icon  = $icons[$s] ?? '<i class="fa fa-question"></i> '; // default tanda tanya

    // Tampilkan badge
    return '<span style="background:'.$color.';color:#fff;padding:6px 12px;border-radius:20px;font-weight:bold;font-size:13px;">'.$icon.ucfirst($status).'</span>';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Motor Disewa - Pemilik</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { margin:0; font-family:'Segoe UI', Tahoma, sans-serif; background:#f1f3f6; }
.sidebar { width:220px; background:#111827; color:white; height:100vh; position:fixed; padding-top:20px; }
.sidebar h2 { text-align:center; margin-bottom:20px; font-size:18px; }
.sidebar a { display:block; color:white; padding:10px 20px; text-decoration:none; font-size:14px; }
.sidebar a:hover, .sidebar a.active { background:#2563eb; }
.main { margin-left:220px; padding:20px; min-height:100vh; }
h1 { text-align:center; margin-bottom:20px; color:#34495e; }
.container { display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:20px; justify-items:center; }
.card { background:white; border-radius:12px; padding:10px; box-shadow:0 3px 12px rgba(0,0,0,0.1); transition: transform 0.2s, box-shadow 0.2s; display:flex; flex-direction:column; }
.card:hover { transform:translateY(-4px); box-shadow:0 6px 15px rgba(0,0,0,0.15); }
.card img { width:100%; height:140px; object-fit:cover; border-radius:10px; margin-bottom:10px; }
.card h3 { margin:0 0 8px; font-size:18px; color:#34495e; text-align:center; }
.card p { margin:4px 0; font-size:14px; color:#7f8c8d; text-align:center; }
.card .status { display:inline-block; margin-top:8px; }
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_pemilik.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="motor_pemilik.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_tersedia_pemilik.php"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="generate_daftar_motor_disewa_pemilik.php" class="active"><i class="fa fa-list"></i> Motor Disewa</a>
    <a href="history_bagi_hasil_pemilik.php"><i class="fa fa-history"></i> Bagi Hasil</a>
    <a href="generate_total_pendapatan_pemilik.php"><i class="fa fa-chart-line"></i> Total Pendapatan</a>
</div>

<div class="main">
    <h1>Daftar Motor Disewa</h1>

    <div class="container">
    <?php if($result->num_rows > 0):
        while($row = $result->fetch_assoc()):
            $photoPath = (!empty($row['photo']) && file_exists("uploads_motor/".$row['photo'])) ? "uploads_motor/".$row['photo'] : "https://via.placeholder.com/400x200?text=No+Image";
    ?>
        <div class="card">
            <img src="<?= htmlspecialchars($photoPath) ?>" alt="Foto Motor">
            <h3><?= htmlspecialchars($row['motor']); ?></h3>
            <p><i class="fa fa-user"></i> Penyewa: <?= htmlspecialchars($row['penyewa']); ?></p>
            <p><i class="fa fa-calendar-alt"></i> Mulai: <?= htmlspecialchars($row['tanggal_mulai']); ?></p>
            <p><i class="fa fa-calendar-check"></i> Selesai: <?= htmlspecialchars($row['tanggal_selesai']); ?></p>
            <p class="status"><?= badgeStatus($row['status']); ?></p>
        </div>
    <?php endwhile; else: ?>
        <p style="grid-column:1/-1; text-align:center; font-weight:bold; color:#7f8c8d;">Belum ada data sewa.</p>
    <?php endif; ?>
    </div>
</div>

</body>
</html>
