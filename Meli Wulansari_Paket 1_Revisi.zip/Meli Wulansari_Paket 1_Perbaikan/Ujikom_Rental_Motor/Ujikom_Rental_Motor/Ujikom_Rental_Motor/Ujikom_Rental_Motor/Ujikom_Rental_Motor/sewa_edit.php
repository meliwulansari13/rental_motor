<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

include "koneksi.php";

// Cek ID sewa
if (!isset($_GET['id'])) {
    header("Location: sewa.php");
    exit;
}
$id = (int)$_GET['id'];

// Ambil data sewa
$sql = "SELECT s.*, m.merk, m.tipe_cc, m.plat_nomor, u.nama AS penyewa
        FROM sewa s
        JOIN motor m ON s.motor_id = m.id
        JOIN users u ON s.penyewa_id = u.id
        WHERE s.id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<p>Data penyewaan tidak ditemukan.</p>";
    exit;
}
$data = $result->fetch_assoc();

// Update data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tgl_mulai   = $_POST['tanggal_mulai'];
    $tgl_selesai = $_POST['tanggal_selesai'];
    $status      = $_POST['status'];

    $update = $conn->prepare("UPDATE sewa SET tanggal_mulai=?, tanggal_selesai=?, status=? WHERE id=?");
    $update->bind_param("sssi", $tgl_mulai, $tgl_selesai, $status, $id);
    if ($update->execute()) {
        header("Location: sewa_detail.php?id=".$id."&msg=updated");
        exit;
    } else {
        $error = "Gagal mengupdate data!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Penyewaan</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body{margin:0;font-family:'Segoe UI',sans-serif;background:#f4f6f9;}
.container{max-width:600px;margin:30px auto;background:white;padding:25px;border-radius:12px;box-shadow:0 4px 10px rgba(0,0,0,0.1);}
h2{margin-top:0;color:#34495e;}
form label{display:block;margin-top:12px;font-weight:600;color:#555;}
form input, form select{width:100%;padding:10px;margin-top:5px;border:1px solid #ccc;border-radius:6px;font-size:14px;}
.actions{margin-top:20px;display:flex;gap:10px;}
.actions button,.actions a{padding:10px 16px;border-radius:6px;color:white;text-decoration:none;font-size:14px;border:none;cursor:pointer;}
.btn-save{background:#27ae60;} .btn-save:hover{background:#1e874b;}
.btn-cancel{background:#7f8c8d;} .btn-cancel:hover{background:#616d70;}
.error{color:red;margin-top:10px;}
</style>
</head>
<body>
<div class="container">
    <h2>Edit Penyewaan</h2>

    <?php if (!empty($error)): ?>
        <p class="error"><?= $error ?></p>
    <?php endif; ?>

    <form method="post">
        <label>Motor</label>
        <input type="text" value="<?= htmlspecialchars($data['merk'].' '.$data['tipe_cc'].' / '.$data['plat_nomor']) ?>" disabled>

        <label>Penyewa</label>
        <input type="text" value="<?= htmlspecialchars($data['penyewa']) ?>" disabled>

        <label>Tanggal Mulai</label>
        <input type="date" name="tanggal_mulai" value="<?= $data['tanggal_mulai'] ?>" required>

        <label>Tanggal Selesai</label>
        <input type="date" name="tanggal_selesai" value="<?= $data['tanggal_selesai'] ?>" required>

        <label>Status</label>
        <select name="status" required>
            <option value="pending" <?= $data['status']=='pending'?'selected':'' ?>>Pending</option>
            <option value="aktif" <?= $data['status']=='aktif'?'selected':'' ?>>Aktif</option>
            <option value="selesai" <?= $data['status']=='selesai'?'selected':'' ?>>Selesai</option>
            <option value="batal" <?= $data['status']=='batal'?'selected':'' ?>>Batal</option>
        </select>

        <div class="actions">
            <button type="submit" class="btn-save"><i class="fa fa-save"></i> Simpan</button>
            <a href="sewa_detail.php?id=<?= $id ?>" class="btn-cancel"><i class="fa fa-times"></i> Batal</a>
        </div>
    </form>
</div>
</body>
</html>
