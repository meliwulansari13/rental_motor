<?php
session_start();
include "koneksi.php";

// Cek login & role penyewa
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit();
}

$user_id = intval($_SESSION['user_id']);

// === Proses lapor pengembalian ===
if (isset($_GET['id'], $_GET['aksi'])) {
    $id = (int) $_GET['id'];
    $aksi = $_GET['aksi'];

    if ($aksi === 'lapor') {
        // Pastikan sewa milik user, status aktif/disewa, dan belum pernah dilaporkan
        $cekSql = "SELECT * FROM sewa 
                   WHERE id = ? AND penyewa_id = ? 
                   AND (status = 'aktif' OR status = 'disewa')
                   AND (pengembalian_dilaporkan IS NULL OR pengembalian_dilaporkan = 0)";
        $stmtCek = $conn->prepare($cekSql);
        $stmtCek->bind_param("ii", $id, $user_id);
        $stmtCek->execute();
        $resultCek = $stmtCek->get_result();

        if ($resultCek->num_rows > 0) {
            // Update flag laporan
            $sqlUpdate = "UPDATE sewa SET pengembalian_dilaporkan = 1 WHERE id = ? AND penyewa_id = ?";
            $stmtUpdate = $conn->prepare($sqlUpdate);
            $stmtUpdate->bind_param("ii", $id, $user_id);
            $stmtUpdate->execute();

            $_SESSION['message'] = "✅ Laporan pengembalian berhasil dikirim, tunggu konfirmasi admin.";
        } else {
            $_SESSION['error'] = "❌ Data sewa tidak valid atau sudah dilaporkan.";
        }
    }

    header("Location: lapor_pengembalian.php");
    exit();
}

// === Ambil data sewa yang masih aktif/disewa dan belum dilaporkan ===
$sql = "SELECT s.id, s.tanggal_mulai, s.tanggal_selesai, 
               m.merk, m.plat_nomor
        FROM sewa s
        JOIN motor m ON s.motor_id = m.id
        WHERE s.penyewa_id = ? 
          AND (s.status = 'aktif' OR s.status = 'disewa')
          AND (s.pengembalian_dilaporkan IS NULL OR s.pengembalian_dilaporkan = 0)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Lapor Pengembalian Motor</title>
    <style>
        body {font-family:Segoe UI, sans-serif; background:#f4f6f9; padding:20px;}
        h2 {text-align:center; color:#2c3e50; margin-bottom:20px;}
        table {border-collapse: collapse; width: 100%; background:white; border-radius:8px; overflow:hidden;}
        th, td {border: 1px solid #ddd; padding: 10px; text-align:center;}
        th {background-color: #34495e; color: white;}
        tr:nth-child(even) {background-color: #f9f9f9;}
        .btn-lapor {color:#fff; background:orange; padding:6px 12px; border-radius:6px; font-weight:bold;}
        .btn-lapor:hover {background:darkorange;}
        .message {color:green; font-weight:bold; text-align:center;}
        .error {color:red; font-weight:bold; text-align:center;}
    </style>
</head>
<body>

<h2>📢 Lapor Pengembalian Motor</h2>

<?php if (isset($_SESSION['message'])): ?>
    <p class="message"><?= $_SESSION['message']; unset($_SESSION['message']); ?></p>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <p class="error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
<?php endif; ?>

<?php if ($result && $result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Motor</th>
                <th>Plat Nomor</th>
                <th>Tanggal Sewa</th>
                <th>Tanggal Kembali</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php $no=1; while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= htmlspecialchars($row['merk']); ?></td>
                <td><?= htmlspecialchars($row['plat_nomor']); ?></td>
                <td><?= htmlspecialchars($row['tanggal_mulai']); ?></td>
                <td><?= htmlspecialchars($row['tanggal_selesai']); ?></td>
                <td>
                    <a href="lapor_pengembalian.php?id=<?= $row['id']; ?>&aksi=lapor" 
                       class="btn-lapor" 
                       onclick="return confirm('Yakin ingin lapor pengembalian motor ini?')">
                        Lapor
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p style="text-align:center; font-weight:bold; color:#7f8c8d;">Tidak ada motor yang perlu dilaporkan pengembaliannya.</p>
<?php endif; ?>

</body>
</html>
