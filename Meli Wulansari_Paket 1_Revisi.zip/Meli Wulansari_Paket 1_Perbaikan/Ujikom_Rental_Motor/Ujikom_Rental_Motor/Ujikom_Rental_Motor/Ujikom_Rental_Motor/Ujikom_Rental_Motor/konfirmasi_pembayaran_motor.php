<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Konfirmasi pembayaran
if (isset($_GET['konfirmasi_id'])) {
    $id_sewa = (int)$_GET['konfirmasi_id'];

    // Update status sewa menjadi aktif
    $conn->query("UPDATE sewa SET status='aktif' WHERE id=$id_sewa");

    // Update status pembayaran, jika belum ada maka buat entri baru
    $cek_pembayaran = $conn->query("SELECT * FROM pembayaran WHERE sewa_id=$id_sewa");
    if($cek_pembayaran->num_rows > 0){
        $conn->query("UPDATE pembayaran SET status='Lunas' WHERE sewa_id=$id_sewa");
    } else {
        $total_harga = $conn->query("SELECT total_harga FROM sewa WHERE id=$id_sewa")->fetch_assoc()['total_harga'];
        $conn->query("INSERT INTO pembayaran (sewa_id, jumlah, status) VALUES ($id_sewa, $total_harga, 'Lunas')");
    }

    // Update status motor menjadi disewa
    $motor_id = $conn->query("SELECT motor_id FROM sewa WHERE id=$id_sewa")->fetch_assoc()['motor_id'];
    $conn->query("UPDATE motor SET status='disewa' WHERE id=$motor_id");

    $_SESSION['msg'] = "✅ Pembayaran berhasil dikonfirmasi. Motor resmi disewa!";
    header("Location: konfirmasi_pembayaran_motor.php");
    exit();
}

// Ambil semua sewa yang belum selesai
$result = $conn->query("
    SELECT 
        s.id AS sewa_id, 
        u.nama AS penyewa, 
        m.id AS motor_id, 
        m.merk, 
        m.tipe_cc, 
        m.plat_nomor, 
        m.photo,
        s.tanggal_mulai, 
        s.tanggal_selesai,
        IF(pb.jumlah>0, pb.jumlah, s.total_harga) AS jumlah,
        IF(pb.status IS NULL OR pb.status='', 'Pending', pb.status) AS status
    FROM sewa s
    JOIN motor m ON s.motor_id = m.id
    JOIN users u ON s.penyewa_id = u.id
    LEFT JOIN pembayaran pb ON pb.sewa_id = s.id
    WHERE s.status != 'selesai'
    ORDER BY s.tanggal_mulai ASC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Konfirmasi Pembayaran Motor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {margin:0;font-family:Segoe UI,sans-serif;background:#f4f6f9;}
        .sidebar {position:fixed;top:0;left:0;width:240px;height:100%;background:#2c3e50;color:#fff;padding-top:20px;overflow-y:auto;}
        .sidebar h2 {text-align:center;margin-bottom:20px;font-size:18px;color:#ecf0f1;}
        .sidebar a {display:block;padding:12px 20px;color:#ecf0f1;text-decoration:none;transition:0.2s;border-left:4px solid transparent;font-size:14px;}
        .sidebar a:hover {background:#34495e;border-left:4px solid #1abc9c;}
        .navbar {margin-left:240px;height:60px;background:#fff;display:flex;align-items:center;justify-content:space-between;padding:0 20px;box-shadow:0 2px 5px rgba(0,0,0,0.1);}
        .navbar h1 {font-size:20px;color:#2c3e50;margin:0;}
        .navbar a {color:#e74c3c;text-decoration:none;font-weight:bold;}
        .content {margin-left:240px;padding:20px;}
        .msg {text-align:center;margin-bottom:15px;font-weight:bold;color:green;}
        .grid-container {display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:20px;}
        .card {background:#fff; border-radius:12px; padding:15px; box-shadow:0 4px 12px rgba(0,0,0,0.08); text-align:center; transition: transform 0.2s, box-shadow 0.2s;}
        .card:hover {transform:translateY(-5px); box-shadow:0 8px 20px rgba(0,0,0,0.15);}
        .card img {width:100%; max-width:200px; border-radius:8px; margin-bottom:10px;}
        .card-content h3 {margin:5px 0;color:#34495e;}
        .card-content p {margin:3px 0;font-size:14px;color:#7f8c8d;}
        .card-actions {display:flex; justify-content:center; gap:10px; margin-top:10px;}
        .btn-konfirm {background:#27ae60; color:#fff; padding:6px 12px; border-radius:6px; text-decoration:none; font-weight:bold;}
        .btn-detail {background:#2980b9; color:#fff; padding:6px 12px; border-radius:6px; text-decoration:none; font-weight:bold;}
        .btn-konfirm:hover {background:#1f8b4d;}
        .btn-detail:hover {background:#1f6391;}
        .status-pending {color:orange;font-weight:bold;}
        .status-lunas {color:green;font-weight:bold;}
    </style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-money-bill"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-check"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
</div>

<div class="navbar">
    <h1>📌 Konfirmasi Pembayaran Motor</h1>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="content">
    <?php if(isset($_SESSION['msg'])): ?>
        <div class="msg"><?= $_SESSION['msg']; unset($_SESSION['msg']); ?></div>
    <?php endif; ?>

    <?php if ($result && $result->num_rows > 0): ?>
        <div class="grid-container">
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="card">
                    <img src="<?= !empty($row['photo']) ? 'uploads_motor/' . htmlspecialchars($row['photo']) : 'https://via.placeholder.com/200x120?text=No+Image'; ?>" alt="Foto Motor">
                    <div class="card-content">
                        <h3><?= htmlspecialchars($row['merk'].' '.$row['tipe_cc']) ?></h3>
                        <p><strong>Penyewa:</strong> <?= htmlspecialchars($row['penyewa']) ?></p>
                        <p><strong>Plat:</strong> <?= htmlspecialchars($row['plat_nomor']) ?></p>
                        <p><strong>Tanggal:</strong> <?= $row['tanggal_mulai'] ?> s/d <?= $row['tanggal_selesai'] ?></p>
                        <p><strong>Status Pembayaran:</strong> 
                            <span class="<?= strtolower($row['status']) === 'lunas' ? 'status-lunas' : 'status-pending'; ?>">
                                <?= htmlspecialchars($row['status']) ?>
                            </span>
                        </p>
                    </div>
                    <div class="card-actions">
                        <?php if (strtolower($row['status']) !== 'lunas'): ?>
                            <a href="?konfirmasi_id=<?= $row['sewa_id'] ?>" class="btn-konfirm" onclick="return confirm('Konfirmasi pembayaran ini?')">Konfirmasi</a>
                        <?php else: ?>
                            <span class="status-lunas">✅ Sudah Lunas</span>
                        <?php endif; ?>
                        <a href="detail_motor.php?id=<?= $row['motor_id'] ?>" class="btn-detail">Detail</a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p style="text-align:center;color:#7f8c8d;font-weight:bold;">Tidak ada motor yang menunggu konfirmasi pembayaran.</p>
    <?php endif; ?>
</div>

</body>
</html>
