<?php
session_start();
include "koneksi.php";

// Cek login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit();
}

$id_user = intval($_SESSION['user_id']);
$role    = $_SESSION['role'];

// Ambil data user
$sql = $conn->prepare("SELECT nama, email, password FROM users WHERE id=?");
$sql->bind_param("i", $id_user);
$sql->execute();
$user = $sql->get_result()->fetch_assoc();

// Tentukan dashboard sesuai role
$dashboard = "login.php";
if ($role == "penyewa") {
    $dashboard = "dashboard_penyewa.php";
} elseif ($role == "pemilik") {
    $dashboard = "dashboard_pemilik.php";
} elseif ($role == "admin") {
    $dashboard = "dashboard_admin.php";
}

// Proses update password
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password_baru'], $_POST['password_konfirmasi'])) {
    $password_baru = trim($_POST['password_baru']);
    $password_konfirmasi = trim($_POST['password_konfirmasi']);

    if ($password_baru === "" || $password_konfirmasi === "") {
        $message = "❌ Password tidak boleh kosong.";
    } elseif ($password_baru !== $password_konfirmasi) {
        $message = "❌ Password baru dan konfirmasi tidak sama.";
    } else {
        // Simpan password baru (hash)
        $hash = password_hash($password_baru, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE users SET password=? WHERE id=?");
        $update->bind_param("si", $hash, $id_user);
        if ($update->execute()) {
            $message = "✅ Password berhasil diperbarui.";
        } else {
            $message = "❌ Gagal update password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Profile <?= ucfirst($role) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { background:#f4f6f9; font-family:'Segoe UI', Tahoma, sans-serif; }
.card-profile { max-width:450px; margin:50px auto; border-radius:12px; background:#fff; box-shadow:0 3px 8px rgba(0,0,0,0.1); padding:20px; text-align:center; }
.card-profile h3 { margin-top:15px; }
.card-profile p { margin:5px 0; color:#555; }
.emoji-avatar { font-size:60px; }
.btn-back { margin-top:20px; }
.role-badge { display:inline-block; margin-top:8px; padding:5px 10px; border-radius:8px; font-size:13px; font-weight:bold; color:#fff; }
.role-penyewa { background:#2980b9; }
.role-pemilik { background:#27ae60; }
.role-admin { background:#e67e22; }
.form-password { text-align:left; margin-top:20px; }
.alert { margin-top:15px; }
</style>
</head>
<body>

<div class="card-profile">
    <div class="emoji-avatar">👤</div>
    <h3><?= htmlspecialchars($user['nama'] ?? '-') ?></h3>
    <span class="role-badge role-<?= strtolower($role) ?>">
        <?= ucfirst($role) ?>
    </span>
    <p><i class="fa fa-envelope"></i> <?= htmlspecialchars($user['email'] ?? '-') ?></p>

    <?php if ($message): ?>
        <div class="alert alert-info"><?= $message ?></div>
    <?php endif; ?>

    <!-- Form ganti password -->
    <form method="post" class="form-password">
        <div class="mb-3">
            <label class="form-label">Password Baru</label>
            <input type="password" name="password_baru" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Konfirmasi Password Baru</label>
            <input type="password" name="password_konfirmasi" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success w-100"><i class="fa fa-key"></i> Ganti Password</button>
    </form>

    <a href="<?= $dashboard ?>" class="btn btn-primary btn-back w-100"><i class="fa fa-arrow-left"></i> Kembali ke Dashboard</a>
</div>

</body>
</html>
