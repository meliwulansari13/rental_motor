<?php
session_start();
include "koneksi.php";

// hanya penyewa
if ($_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit();
}

$msg = "";

// Proses booking motor
if (isset($_POST['pesan'])) {
    $penyewa_id = $_SESSION['user_id'];
    $motor_id   = $_POST['motor_id'];
    $durasi     = $_POST['durasi'];
    $tanggal_mulai = $_POST['tanggal_mulai'];

    $motor = mysqli_fetch_assoc(mysqli_query($conn, "SELECT harga_sewa FROM motor WHERE id='$motor_id'"));
    $harga_sewa = $motor['harga_sewa'];
    $total_harga = $durasi * $harga_sewa;
    $tanggal_selesai = date('Y-m-d', strtotime($tanggal_mulai . " +$durasi days"));

    $sql = "INSERT INTO sewa (penyewa_id, motor_id, durasi, tanggal_mulai, tanggal_selesai, total_harga, status) 
            VALUES ('$penyewa_id','$motor_id','$durasi','$tanggal_mulai','$tanggal_selesai','$total_harga','Pending')";
    if (mysqli_query($conn, $sql)) {
        $msg = "Pesanan berhasil dibuat! Total biaya: Rp " . number_format($total_harga,0,',','.');
    } else {
        $msg = "Gagal memesan motor.";
    }
}

$motors = mysqli_query($conn, "SELECT m.*, u.nama AS pemilik 
                              FROM motor m 
                              JOIN users u ON m.pemilik_id=u.id
                              WHERE m.status='tersedia'");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pilih Motor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
    body { font-family: 'Segoe UI', sans-serif; background:#f4f6f9; margin:0; padding:20px; }
    h2 { margin-bottom:20px; }
    .msg { margin-bottom:20px; font-weight:bold; }
    .cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:20px; }
    .card { background:#fff; padding:20px; border-radius:12px; box-shadow:0 3px 8px rgba(0,0,0,0.08); display:flex; flex-direction:column; gap:10px; }
    .card h3 { margin:0; font-size:18px; }
    .card p { margin:0; font-size:14px; color:#555; }
    .card form { display:flex; flex-direction:column; gap:8px; }
    .card input, .card select, .card button { padding:8px; border-radius:6px; border:1px solid #ccc; font-size:14px; }
    .card button { background:#3498db; color:#fff; border:none; cursor:pointer; transition:0.3s; }
    .card button:hover { background:#2980b9; }
    </style>
</head>
<body>

<h2>Pilih Motor</h2>
<?php if($msg) echo "<div class='msg'>$msg</div>"; ?>

<div class="cards">
<?php while($row = mysqli_fetch_assoc($motors)) { ?>
    <div class="card">
        <h3><?= htmlspecialchars($row['merk']) ?> - <?= htmlspecialchars($row['plat_nomor']) ?></h3>
        <p>Pemilik: <?= htmlspecialchars($row['pemilik']) ?></p>
        <p>Harga Sewa: Rp <?= number_format($row['harga_sewa'],0,',','.') ?>/hari</p>
        <form method="post">
            <input type="hidden" name="motor_id" value="<?= $row['id'] ?>">
            <label>Tanggal Mulai:</label>
            <input type="date" name="tanggal_mulai" required>
            <label>Durasi (hari):</label>
            <input type="number" name="durasi" min="1" value="1" required>
            <button type="submit" name="pesan">Pesan Motor</button>
        </form>
    </div>
<?php } ?>
</div>

</body>
</html>
