<?php
session_start();
include "koneksi.php";

// Pastikan admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$edit_motor_id = isset($_GET['edit_motor_id']) ? (int)$_GET['edit_motor_id'] : 0;
$edit_data = null;

if ($edit_motor_id) {
    // Ambil data motor
    $motor_stmt = $conn->prepare("SELECT * FROM motor WHERE id = ?");
    $motor_stmt->bind_param("i", $edit_motor_id);
    $motor_stmt->execute();
    $motor_data = $motor_stmt->get_result()->fetch_assoc() ?: [];
    $motor_stmt->close();

    // Ambil data tarif
    $tarif_stmt = $conn->prepare("SELECT jenis, harga FROM tarif WHERE motor_id = ?");
    $tarif_stmt->bind_param("i", $edit_motor_id);
    $tarif_stmt->execute();
    $res_tarif = $tarif_stmt->get_result();

    $tarif_arr = ['harian'=>'','mingguan'=>'','bulanan'=>''];
    while($row = $res_tarif->fetch_assoc()) {
        $tarif_arr[$row['jenis']] = $row['harga'];
    }
    $tarif_stmt->close();

    $edit_data = [
        'motor_id' => $edit_motor_id,
        'merk' => $motor_data['merk'] ?? '',
        'tipe_cc' => $motor_data['tipe_cc'] ?? '',
        'plat_nomor' => $motor_data['plat_nomor'] ?? '',
        'harian' => $tarif_arr['harian'],
        'mingguan' => $tarif_arr['mingguan'],
        'bulanan' => $tarif_arr['bulanan'],
    ];
}

// Proses submit update
if (isset($_POST['simpan']) && $edit_motor_id) {
    $harian   = (int)$_POST['harian'];
    $mingguan = (int)$_POST['mingguan'];
    $bulanan  = (int)$_POST['bulanan'];

    // Update tiap jenis tarif
    $stmt = $conn->prepare("UPDATE tarif SET harga=? WHERE motor_id=? AND jenis=?");
    foreach(['harian'=>$harian,'mingguan'=>$mingguan,'bulanan'=>$bulanan] as $jenis => $harga) {
        $stmt->bind_param("iis",$harga,$edit_motor_id,$jenis);
        $stmt->execute();
    }
    $stmt->close();

    $_SESSION['msg'] = "Tarif motor berhasil diperbarui!";
    header("Location: tarif.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Tarif Motor</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { font-family:'Segoe UI',sans-serif; background:#f2f3f5; margin:0; padding:20px;}
.container { max-width:600px; margin:auto; background:#fff; padding:25px; border-radius:12px; box-shadow:0 4px 8px rgba(0,0,0,0.1);}
h2 { text-align:center; margin-bottom:25px; color:#333;}
label { display:block; margin-bottom:6px; font-weight:600;}
input { width:100%; padding:10px; margin-bottom:18px; border-radius:8px; border:1px solid #ccc; font-size:14px;}
.btn { padding:12px 20px; border:none; border-radius:8px; font-size:14px; cursor:pointer; text-align:center;}
.btn-save { background:#5c6bc0; color:white;}
.btn-save:hover { background:#3f51b5; }
.btn-back { background:#e0e0e0; color:#333; text-decoration:none; padding:12px 20px; border-radius:8px; display:inline-block; margin-left:10px;}
</style>
</head>
<body>
<div class="container">
    <h2><i class="fa fa-edit"></i> Edit Tarif Motor</h2>
    <?php if($edit_data): ?>
    <form method="post">
        <label>Motor</label>
        <input type="text" value="<?= htmlspecialchars($edit_data['merk'].' '.$edit_data['tipe_cc'].' / '.$edit_data['plat_nomor']) ?>" disabled>

        <label>Tarif Harian</label>
        <input type="number" name="harian" required value="<?= $edit_data['harian'] ?>">

        <label>Tarif Mingguan</label>
        <input type="number" name="mingguan" required value="<?= $edit_data['mingguan'] ?>">

        <label>Tarif Bulanan</label>
        <input type="number" name="bulanan" required value="<?= $edit_data['bulanan'] ?>">

        <button type="submit" name="simpan" class="btn btn-save"><i class="fa fa-save"></i> Update Tarif</button>
        <a href="tarif.php" class="btn-back"><i class="fa fa-arrow-left"></i> Kembali</a>
    </form>
    <?php else: ?>
        <div class="info">Motor tidak ditemukan atau belum dipilih.</div>
        <a href="tarif.php" class="btn-back"><i class="fa fa-arrow-left"></i> Kembali</a>
    <?php endif; ?>
</div>
</body>
</html>