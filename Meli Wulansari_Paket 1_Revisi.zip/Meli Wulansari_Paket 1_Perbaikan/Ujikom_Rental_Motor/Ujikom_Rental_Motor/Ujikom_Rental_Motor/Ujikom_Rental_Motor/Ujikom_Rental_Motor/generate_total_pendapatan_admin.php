<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Ambil filter periode dari URL
$periode = isset($_GET['periode']) ? $_GET['periode'] : 'bulan';

// Query total pendapatan berdasarkan periode
switch ($periode) {
    case 'hari':
        $sql = "SELECT DATE(tanggal_bayar) AS periode, SUM(jumlah) AS total
                FROM pembayaran
                GROUP BY DATE(tanggal_bayar)
                ORDER BY DATE(tanggal_bayar) DESC";
        break;
    case 'minggu':
        $sql = "SELECT YEAR(tanggal_bayar) AS tahun, WEEK(tanggal_bayar, 1) AS minggu, SUM(jumlah) AS total
                FROM pembayaran
                GROUP BY YEAR(tanggal_bayar), WEEK(tanggal_bayar, 1)
                ORDER BY YEAR(tanggal_bayar) DESC, WEEK(tanggal_bayar, 1) DESC";
        break;
    case 'tahun':
        $sql = "SELECT YEAR(tanggal_bayar) AS periode, SUM(jumlah) AS total
                FROM pembayaran
                GROUP BY YEAR(tanggal_bayar)
                ORDER BY YEAR(tanggal_bayar) DESC";
        break;
    default: // bulan
        $sql = "SELECT DATE_FORMAT(tanggal_bayar, '%Y-%m') AS periode, SUM(jumlah) AS total
                FROM pembayaran
                GROUP BY DATE_FORMAT(tanggal_bayar, '%Y-%m')
                ORDER BY DATE_FORMAT(tanggal_bayar, '%Y-%m') DESC";
}

$result = $conn->query($sql);
$totals = [];
$labels = [];
while ($row = $result->fetch_assoc()) {
    $labels[] = ($periode == 'minggu') ? "Tahun {$row['tahun']} - Minggu {$row['minggu']}" : $row['periode'];
    $totals[] = $row['total'];
}

// Hitung total keseluruhan
$total_keseluruhan = $conn->query("SELECT SUM(jumlah) AS total_keseluruhan FROM pembayaran")->fetch_assoc()['total_keseluruhan'] ?? 0;

// Total per hari, minggu, bulan
$total_harian = $conn->query("SELECT SUM(jumlah) AS total_harian FROM pembayaran WHERE DATE(tanggal_bayar) = CURDATE()")->fetch_assoc()['total_harian'] ?? 0;
$total_mingguan = $conn->query("SELECT SUM(jumlah) AS total_mingguan FROM pembayaran WHERE YEARWEEK(tanggal_bayar,1) = YEARWEEK(CURDATE(),1)")->fetch_assoc()['total_mingguan'] ?? 0;
$total_bulanan = $conn->query("SELECT SUM(jumlah) AS total_bulanan FROM pembayaran WHERE YEAR(tanggal_bayar) = YEAR(CURDATE()) AND MONTH(tanggal_bayar) = MONTH(CURDATE())")->fetch_assoc()['total_bulanan'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Total Pendapatan - Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
* { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI', Tahoma, sans-serif; }

/* Sidebar */
.navbar {
    position: fixed;
    top: 0; left: 0;
    width: 220px;
    height: 100vh;
    background:#1f2937;
    display:flex;
    flex-direction:column;
    align-items:center;
    padding:15px 0;
    overflow-y:auto;
}
.navbar h2 { color:white; margin-bottom:20px; font-size:20px; text-align:center; }
.navbar a {
    width:90%;
    background:#374151;
    color:white;
    padding:12px 10px;
    margin:5px 0;
    border-radius:10px;
    display:flex;
    align-items:center;
    gap:10px;
    text-decoration:none;
    transition:0.2s;
}
.navbar a i { width:20px; text-align:center; }
.navbar a:hover, .navbar a.active { background:#2563eb; }

/* Main content */
.main { margin-left:240px; padding:20px; min-height:100vh; background:#f4f6f9; }

/* Page heading */
h1 { text-align:center; margin-bottom:20px; }

/* Summary cards */
.summary-boxes { display:flex; gap:15px; flex-wrap:wrap; justify-content:center; margin-bottom:20px; }
.summary { flex:1; min-width:150px; padding:15px; border-radius:10px; color:white; text-align:center; font-weight:bold; box-shadow:0 3px 8px rgba(0,0,0,0.1); }
.summary.hari { background:#10b981; }
.summary.minggu { background:#f59e0b; }
.summary.bulan { background:#3b82f6; }

/* Table */
table { width:100%; border-collapse:collapse; background:white; border-radius:8px; overflow:hidden; box-shadow:0 3px 8px rgba(0,0,0,0.1); }
th, td { padding:10px; text-align:center; border:1px solid #ccc; font-size:14px; }
th { background:#e5e7eb; font-weight:bold; }
tr:nth-child(even) { background:#f9fafb; }

/* Filter periode */
.filter { text-align:center; margin:20px 0; }
.filter a { padding:6px 12px; margin:0 5px; border-radius:6px; text-decoration:none; background:#2563eb; color:white; }
.filter a.active { background:#10b981; font-weight:bold; }

/* Buttons */
.btn-print { display:inline-block; padding:8px 16px; background:#2563eb; color:white; border-radius:6px; text-decoration:none; margin-bottom:20px; cursor:pointer; }
.btn-print:hover { background:#1d4ed8; }

/* Total keseluruhan */
.total { text-align:right; margin-top:15px; font-weight:bold; font-size:16px; }

/* Print styles */
.print-header { display:none; text-align:center; margin-bottom:20px; }
.print-header h2 { margin:0; }
.print-header hr { border:1px solid #000; margin-top:5px; }
@media print {
    body { background:#fff; }
    .navbar, .btn-print, .filter, .summary-boxes { display:none; }
    .main { margin:0; padding:0; }
    table { box-shadow:none; }
    .print-header { display:block; text-align:center; margin-bottom:20px; }
}
</style>
</head>
<body>

<div class="navbar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-hourglass-half"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php" class="active"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>

<div class="main">
    <h1>Total Pendapatan</h1>

    <div class="summary-boxes">
        <div class="summary hari">Hari Ini<br>Rp <?= number_format($total_harian,0,',','.'); ?></div>
        <div class="summary minggu">Minggu Ini<br>Rp <?= number_format($total_mingguan,0,',','.'); ?></div>
        <div class="summary bulan">Bulan Ini<br>Rp <?= number_format($total_bulanan,0,',','.'); ?></div>
    </div>

    <div style="text-align:center; margin-bottom:20px;">
        <a href="#" class="btn-print" onclick="window.print(); return false;"><i class="fa fa-print"></i> Cetak</a>
        <a href="export_total_pendapatan_pdf.php?periode=<?= $periode; ?>" class="btn-print"><i class="fa fa-file-pdf"></i> Export PDF</a>
        <a href="export_total_pendapatan_excel.php?periode=<?= $periode; ?>" class="btn-print"><i class="fa fa-file-excel"></i> Export Excel</a>
    </div>

    <div class="print-header">
        <h2>Laporan Total Pendapatan</h2>
        <hr>
    </div>

    <div class="filter">
        <a href="?periode=hari" class="<?= $periode=='hari'?'active':'' ?>">Harian</a>
        <a href="?periode=minggu" class="<?= $periode=='minggu'?'active':'' ?>">Mingguan</a>
        <a href="?periode=bulan" class="<?= $periode=='bulan'?'active':'' ?>">Bulanan</a>
        <a href="?periode=tahun" class="<?= $periode=='tahun'?'active':'' ?>">Tahunan</a>
    </div>

    <table>
        <tr>
            <th>No</th>
            <th>Periode</th>
            <th>Total Pendapatan (Rp)</th>
        </tr>
        <?php if(count($totals) > 0): ?>
            <?php foreach($totals as $i => $total): ?>
                <tr>
                    <td><?= $i+1 ?></td>
                    <td><?= $labels[$i] ?></td>
                    <td>Rp <?= number_format($total,0,',','.'); ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="3">Belum ada data pembayaran.</td>
            </tr>
        <?php endif; ?>
    </table>

    <div class="total">
        Total Keseluruhan: Rp <?= number_format($total_keseluruhan,0,',','.'); ?>
    </div>
</div>
</body>
</html>
