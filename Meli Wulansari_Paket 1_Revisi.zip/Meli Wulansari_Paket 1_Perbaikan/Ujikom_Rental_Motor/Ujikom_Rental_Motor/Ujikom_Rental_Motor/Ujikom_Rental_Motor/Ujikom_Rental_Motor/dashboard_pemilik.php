<?php
session_start();
include "koneksi.php";

// Cek login & role pemilik
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

$id_pemilik = $_SESSION['user_id'];

// Ambil nama pemilik
$q_user = $conn->prepare("SELECT nama FROM users WHERE id = ?");
$q_user->bind_param("i", $id_pemilik);
$q_user->execute();
$nama_pemilik = $q_user->get_result()->fetch_assoc()['nama'] ?? 'Pemilik';

// Total motor milik pemilik
$q_motor = $conn->prepare("SELECT COUNT(*) AS jml FROM motor WHERE pemilik_id=?");
$q_motor->bind_param("i", $id_pemilik);
$q_motor->execute();
$total_motor = $q_motor->get_result()->fetch_assoc()['jml'] ?? 0;

// Motor tersedia
$q_tersedia = $conn->prepare("SELECT COUNT(*) AS jml FROM motor WHERE pemilik_id=? AND status='tersedia'");
$q_tersedia->bind_param("i", $id_pemilik);
$q_tersedia->execute();
$total_tersedia = $q_tersedia->get_result()->fetch_assoc()['jml'] ?? 0;

// Motor sedang disewa
$q_disewa = $conn->prepare("SELECT COUNT(*) AS jml 
                            FROM sewa s 
                            JOIN motor m ON s.motor_id=m.id 
                            WHERE m.pemilik_id=? AND s.status='aktif'");
$q_disewa->bind_param("i", $id_pemilik);
$q_disewa->execute();
$total_disewa = $q_disewa->get_result()->fetch_assoc()['jml'] ?? 0;

// Total pendapatan
$q_pendapatan = $conn->prepare("SELECT SUM(p.jumlah) AS total 
                                FROM pembayaran p
                                JOIN sewa s ON p.sewa_id = s.id
                                JOIN motor m ON s.motor_id = m.id
                                WHERE m.pemilik_id=?");
$q_pendapatan->bind_param("i", $id_pemilik);
$q_pendapatan->execute();
$total_pendapatan = $q_pendapatan->get_result()->fetch_assoc()['total'] ?? 0;

// Transaksi terakhir
$sql = "SELECT p.id, u.nama AS penyewa, 
               CONCAT(m.merk, ' ', m.tipe_cc) AS motor, 
               p.jumlah, s.status
        FROM pembayaran p
        JOIN sewa s ON p.sewa_id = s.id
        JOIN users u ON s.penyewa_id = u.id
        JOIN motor m ON s.motor_id = m.id
        WHERE m.pemilik_id=?
        ORDER BY p.id DESC LIMIT 5";
$q_transaksi = $conn->prepare($sql);
$q_transaksi->bind_param("i", $id_pemilik);
$q_transaksi->execute();
$transaksi = $q_transaksi->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Pemilik</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* Reset dan body */
body { margin:0; font-family:'Segoe UI', Tahoma, sans-serif; background:#f4f6f9; }

/* Sidebar */
.sidebar {
    width:230px; background:#111; height:100vh; position:fixed; top:0; left:0; color:white; display:flex; flex-direction:column;
}
.sidebar h2 { text-align:center; padding:20px; margin:0; font-size:20px; font-weight:bold; background:#000; border-bottom:2px solid #f5eaeaff; }
.sidebar a { display:block; padding:14px 20px; color:#ccc; text-decoration:none; font-size:14px; border-left:4px solid transparent; transition:0.2s; }
.sidebar a:hover, .sidebar a.active { background:#222; color:#fff; border-left:4px solid #ebf6fdff; }

/* Topbar */
.topbar { margin-left:230px; background:linear-gradient(90deg,#2980b9,#8e44ad); padding:15px 20px; display:flex; justify-content:space-between; align-items:center; color:white; position:sticky; top:0; z-index:10; }
.topbar h1 { margin:0; font-size:22px; font-weight:bold; }
.dropdown { position:relative; display:inline-block; }
.dropbtn { background:transparent; border:none; color:white; font-size:14px; cursor:pointer; padding:8px 12px; border-radius:6px; }
.dropbtn:hover { background:rgba(255,255,255,0.1); }
.dropdown-content { display:none; position:absolute; right:0; background:#fff; min-width:160px; box-shadow:0px 8px 16px rgba(0,0,0,0.2); border-radius:8px; overflow:hidden; z-index:99; }
.dropdown-content a { color:#333; padding:10px 15px; text-decoration:none; display:block; font-size:14px; transition:0.2s; }
.dropdown-content a:hover { background:#f1f1f1; }
.show { display:block; }

/* Main content */
.main { margin-left:230px; padding:20px; }
.cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:20px; margin-bottom:30px; }
.card { background:#fff; border-radius:12px; padding:20px; display:flex; align-items:center; gap:15px; text-decoration:none; color:inherit; transition:0.3s; }
.card:hover { transform:translateY(-4px); box-shadow:0 6px 12px rgba(0,0,0,0.15); }
.icon { font-size:28px; padding:18px; border-radius:50%; color:#fff; flex-shrink:0; }
.blue { background:#3498db; }
.green{ background:#27ae60; }
.orange{ background:#e67e22; }
.purple{ background:#9b59b6; }
.card-content h3 { margin:0; font-size:20px; font-weight:bold; color:#2c3e50; }
.card-content p { margin:5px 0 0; font-size:13px; color:#7f8c8d; }

/* Table */
.table-box { background:#fff; border-radius:12px; padding:20px; box-shadow:0 3px 8px rgba(0,0,0,0.08); margin-bottom:30px; overflow-x:auto; }
table { width:100%; border-collapse:collapse; margin-top:15px; min-width:600px; }
th,td { padding:12px; text-align:center; font-size:14px; border-bottom:1px solid #eee;}
th { background:#34495e; color:white; }
tr:hover { background:#f9f9f9; }
.status { padding:4px 8px; border-radius:5px; font-size:12px; font-weight:bold;}
.aktif { background:#f39c12; color:white; }
.selesai { background:#27ae60; color:white; }
.batal { background:#e74c3c; color:white; }

/* Footer */
footer { margin-left:230px; padding:10px 20px; text-align:center; color:#555; font-size:13px; }

/* Responsif */
@media(max-width:768px){ .sidebar { width:200px; } .topbar, .main { margin-left:200px; } }
@media(max-width:576px){ .sidebar { position:absolute; left:-230px; } .sidebar.active { left:0; } .topbar, .main { margin-left:0; } }
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_pemilik.php" class="active"><i class="fa fa-home"></i> Dashboard</a>
    <a href="motor_pemilik.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_tersedia_pemilik.php"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="generate_daftar_motor_disewa_pemilik.php"><i class="fa fa-list"></i> Motor Disewa</a>
    <a href="history_bagi_hasil_pemilik.php"><i class="fa fa-history"></i> Bagi Hasil</a>
    <a href="generate_total_pendapatan_pemilik.php"><i class="fa fa-chart-line"></i> Total Pendapatan</a>
</div>

<!-- Topbar -->
<div class="topbar">
    <h1>Dashboard Pemilik</h1>
    <div class="user">
        <div class="dropdown">
            <button class="dropbtn" onclick="toggleDropdown()">
                <i class="fa fa-user-circle"></i> <?= htmlspecialchars($nama_pemilik) ?> <i class="fa fa-caret-down"></i>
            </button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Main content -->
<div class="main">
    <div class="cards">
        <a href="profile.php" class="card">
            <div class="icon purple"><i class="fa fa-user-circle"></i></div>
            <div class="card-content">
                <h3><?= htmlspecialchars($nama_pemilik); ?></h3>
                <p>Profil</p>
            </div>
        </a>
        <a href="motor_pemilik.php" class="card">
            <div class="icon green"><i class="fa fa-motorcycle"></i></div>
            <div class="card-content">
                <h3><?= $total_motor; ?></h3>
                <p>Total Motor</p>
            </div>
        </a>
        <a href="motor_tersedia_pemilik.php" class="card">
            <div class="icon blue"><i class="fa fa-check-circle"></i></div>
            <div class="card-content">
                <h3><?= $total_tersedia; ?></h3>
                <p>Motor Tersedia</p>
            </div>
        </a>
        <a href="generate_daftar_motor_disewa_pemilik.php" class="card">
            <div class="icon orange"><i class="fa fa-list"></i></div>
            <div class="card-content">
                <h3><?= $total_disewa; ?></h3>
                <p>Motor Disewa</p>
            </div>
        </a>
        <a href="generate_total_pendapatan_pemilik.php" class="card">
            <div class="icon purple"><i class="fa fa-money-bill"></i></div>
            <div class="card-content">
                <h3>Rp <?= number_format($total_pendapatan,0,',','.'); ?></h3>
                <p>Total Pendapatan</p>
            </div>
        </a>
    </div>

    <div class="table-box">
    <h3>Grafik Pendapatan Transaksi Terakhir</h3>
    <canvas id="grafikPendapatan" style="width:100%; height:300px;"></canvas>
</div>

<?php
// Ambil data transaksi terakhir untuk chart
$q_chart = $conn->prepare("SELECT p.jumlah, s.status, u.nama AS penyewa 
                           FROM pembayaran p
                           JOIN sewa s ON p.sewa_id = s.id
                           JOIN users u ON s.penyewa_id = u.id
                           JOIN motor m ON s.motor_id = m.id
                           WHERE m.pemilik_id=?
                           ORDER BY p.id DESC LIMIT 10");
$q_chart->bind_param("i", $id_pemilik);
$q_chart->execute();
$res_chart = $q_chart->get_result();

$chart_labels = [];
$chart_data = [];
$chart_status = [];
while($row = $res_chart->fetch_assoc()){
    $chart_labels[] = htmlspecialchars($row['penyewa']);
    $chart_data[] = $row['jumlah'];
    $chart_status[] = $row['status'];
}

// Konversi ke JSON untuk JS
$chart_labels_json = json_encode(array_reverse($chart_labels));
$chart_data_json   = json_encode(array_reverse($chart_data));
$chart_status_json = json_encode(array_reverse($chart_status));
?>
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('grafikPendapatan').getContext('2d');
const grafikPendapatan = new Chart(ctx, {
    type: 'bar', // bisa diganti 'line' atau 'bar'
    data: {
        labels: <?= $chart_labels_json ?>,
        datasets: [{
            label: 'Jumlah Bayar (Rp)',
            data: <?= $chart_data_json ?>,
            backgroundColor: 'rgba(46, 204, 113, 0.7)',
            borderColor: 'rgba(39, 174, 96, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            tooltip: { callbacks: {
                label: function(context) {
                    return 'Rp ' + context.raw.toLocaleString('id-ID');
                }
            } }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: { callback: function(value){ return 'Rp ' + value.toLocaleString('id-ID'); } }
            }
        }
    }
});
</script>

</body>
</html>
