<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

include "koneksi.php";

// Ambil semua motor + tarif aktif
$motor = $conn->query("SELECT m.id, m.merk, m.tipe_cc, m.plat_nomor,
    MAX(CASE WHEN t.jenis='harian' THEN t.harga END) AS tarif_harian,
    MAX(CASE WHEN t.jenis='mingguan' THEN t.harga END) AS tarif_mingguan,
    MAX(CASE WHEN t.jenis='bulanan' THEN t.harga END) AS tarif_bulanan
    FROM motor m
    LEFT JOIN tarif t ON t.motor_id=m.id AND t.status='aktif'
    GROUP BY m.id
    ORDER BY m.merk, m.plat_nomor");

// Ambil semua penyewa
$penyewa = $conn->query("SELECT * FROM users WHERE role='penyewa'");

if (isset($_POST['submit'])) {
    $motor_id = intval($_POST['motor_id']);
    $penyewa_id = intval($_POST['penyewa_id']);
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tipe_durasi = $_POST['tipe_durasi'];
    $status = $_POST['status'];

    // Ambil tarif motor aktif
    $stmt_tarif = $conn->prepare("SELECT jenis, harga FROM tarif WHERE motor_id=? AND status='aktif'");
    $stmt_tarif->bind_param("i", $motor_id);
    $stmt_tarif->execute();
    $res_tarif = $stmt_tarif->get_result();
    $tarif = ['harian'=>0,'mingguan'=>0,'bulanan'=>0];
    while($row = $res_tarif->fetch_assoc()){
        $tarif[$row['jenis']] = $row['harga'];
    }
    $stmt_tarif->close();

    // Hitung tanggal selesai & total harga
    if ($tipe_durasi=='harian') {
        $tanggal_selesai = date('Y-m-d', strtotime($tanggal_mulai.' +1 day'));
        $total = $tarif['harian'];
    } elseif ($tipe_durasi=='mingguan') {
        $tanggal_selesai = date('Y-m-d', strtotime($tanggal_mulai.' +7 days'));
        $total = $tarif['mingguan'];
    } else {
        $tanggal_selesai = date('Y-m-d', strtotime($tanggal_mulai.' +30 days'));
        $total = $tarif['bulanan'];
    }

    $stmt = $conn->prepare("INSERT INTO sewa (motor_id, penyewa_id, tanggal_mulai, tanggal_selesai, tipe_durasi, total_harga, status) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param("iississ", $motor_id, $penyewa_id, $tanggal_mulai, $tanggal_selesai, $tipe_durasi, $total, $status);

    if ($stmt->execute()) {
        header("Location: sewa.php");
        exit;
    } else {
        echo "Error: ".$stmt->error;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Penyewaan Motor</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* styling sama seperti versi edit */
body{font-family:'Segoe UI',sans-serif;background:#f2f3f5;margin:0;padding:0;}
.container{max-width:600px;margin:50px auto;background:#fff;padding:25px;border-radius:12px;box-shadow:0 4px 8px rgba(0,0,0,0.1);}
h2{text-align:center;margin-bottom:25px;color:#333;}
label{font-size:14px;font-weight:600;display:block;margin-bottom:6px;color:#444;}
select,input{width:100%;padding:10px;margin-bottom:18px;border:1px solid #ccc;border-radius:8px;font-size:14px;}
.btn{padding:12px;border:none;border-radius:8px;font-size:15px;cursor:pointer;transition:0.3s;}
.btn-save{width:100%;background:#2980b9;color:white;}
.btn-save:hover{background:#1e6091;}
.btn-back{display:inline-block;margin-top:15px;background:#7f8c8d;color:white;text-decoration:none;padding:10px 18px;border-radius:8px;transition:0.3s;}
.btn-back:hover{background:#636e72;}
#total_harga{font-weight:bold;color:#e74c3c;margin-bottom:18px;}
</style>
</head>
<body>
<div class="container">
<h2><i class="fa fa-plus"></i> Tambah Penyewaan Motor</h2>
<form method="post">
    <label>Motor</label>
    <select name="motor_id" id="motor_id" required>
        <option value="">-- Pilih Motor --</option>
        <?php while($m = $motor->fetch_assoc()): ?>
            <option value="<?= $m['id'] ?>"
                data-harian="<?= $m['tarif_harian'] ?>"
                data-mingguan="<?= $m['tarif_mingguan'] ?>"
                data-bulanan="<?= $m['tarif_bulanan'] ?>">
                <?= $m['merk'].' '.$m['tipe_cc'].' / '.$m['plat_nomor'] ?>
                <?= $m['tarif_harian'] ? '- H: Rp '.number_format($m['tarif_harian'],0,',','.') : '' ?>
                <?= $m['tarif_mingguan'] ? ', M: Rp '.number_format($m['tarif_mingguan'],0,',','.') : '' ?>
                <?= $m['tarif_bulanan'] ? ', B: Rp '.number_format($m['tarif_bulanan'],0,',','.') : '' ?>
            </option>
        <?php endwhile; ?>
    </select>

    <label>Penyewa</label>
    <select name="penyewa_id" required>
        <?php while($p = $penyewa->fetch_assoc()): ?>
            <option value="<?= $p['id'] ?>"><?= $p['nama'] ?></option>
        <?php endwhile; ?>
    </select>

    <label>Tanggal Mulai</label>
    <input type="date" id="tanggal_mulai" name="tanggal_mulai" required>

    <label>Durasi</label>
    <select id="tipe_durasi" name="tipe_durasi" required>
        <option value="harian">Harian</option>
        <option value="mingguan">Mingguan</option>
        <option value="bulanan">Bulanan</option>
    </select>

    <label>Tanggal Kembali</label>
    <input type="text" id="tanggal_selesai" readonly>

    <label>Total Harga</label>
    <input type="text" id="total_harga" readonly>

    <label>Status</label>
    <select name="status" required>
        <option value="aktif">Aktif</option>
        <option value="selesai">Selesai</option>
        <option value="dibatalkan">Dibatalkan</option>
    </select>

    <button type="submit" name="submit" class="btn btn-save"><i class="fa fa-save"></i> Tambah</button>
</form>
<a href="sewa.php" class="btn-back"><i class="fa fa-arrow-left"></i> Kembali</a>
</div>

<script>
const motorSelect = document.getElementById('motor_id');
const durasiSelect = document.getElementById('tipe_durasi');
const tanggalMulai = document.getElementById('tanggal_mulai');
const tanggalSelesai = document.getElementById('tanggal_selesai');
const totalHarga = document.getElementById('total_harga');

function updateSewa(){
    const motorOption = motorSelect.selectedOptions[0];
    const durasi = durasiSelect.value;
    const start = tanggalMulai.value;
    if(!motorOption || !durasi || !start){
        tanggalSelesai.value = '';
        totalHarga.value = '';
        return;
    }
    let harga = 0;
    if(durasi==='harian') harga = motorOption.dataset.harian;
    else if(durasi==='mingguan') harga = motorOption.dataset.mingguan;
    else harga = motorOption.dataset.bulanan;

    let date = new Date(start);
    if(durasi==='harian') date.setDate(date.getDate()+1);
    else if(durasi==='mingguan') date.setDate(date.getDate()+7);
    else date.setDate(date.getDate()+30);

    tanggalSelesai.value = date.toISOString().split('T')[0];
    totalHarga.value = 'Rp ' + Number(harga).toLocaleString('id-ID');
}

window.addEventListener('load', updateSewa);
motorSelect.addEventListener('change', updateSewa);
durasiSelect.addEventListener('change', updateSewa);
tanggalMulai.addEventListener('change', updateSewa);
</script>
</body>
</html>
