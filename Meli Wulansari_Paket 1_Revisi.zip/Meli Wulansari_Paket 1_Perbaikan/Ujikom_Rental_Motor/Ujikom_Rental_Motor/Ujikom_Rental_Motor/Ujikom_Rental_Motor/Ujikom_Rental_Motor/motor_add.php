<?php
include "koneksi.php";

// Ambil daftar pemilik
$pemilik = $conn->query("SELECT id, nama FROM users WHERE role='pemilik'");

if (isset($_POST['submit'])) {
    $pemilik_id = $_POST['pemilik_id'];
    $merk = $_POST['merk'];
    $tipe_cc = $_POST['tipe_cc'];
    $plat_nomor = $_POST['plat_nomor'];
    $status = $_POST['status'];

    // Cek apakah plat_nomor sudah ada
    $cek = $conn->prepare("SELECT id FROM motor WHERE plat_nomor = ?");
    $cek->bind_param("s", $plat_nomor);
    $cek->execute();
    $cek->store_result();

    if ($cek->num_rows > 0) {
        echo "<script>alert('Plat nomor sudah terdaftar!'); window.history.back();</script>";
        exit;
    }

    $cek->close();

    // Upload Foto Motor
    $photo = null;
    if (!empty($_FILES['photo']['name'])) {
        $photo = time() . "_" . $_FILES['photo']['name'];
        move_uploaded_file($_FILES['photo']['tmp_name'], "uploads_motor/" . $photo);
    }

    // Upload Dokumen Kepemilikan
    $dokumen_files = [];
    if (!empty($_FILES['dokumen_kepemilikan']['name'][0])) {
        foreach ($_FILES['dokumen_kepemilikan']['name'] as $key => $val) {
            if ($_FILES['dokumen_kepemilikan']['error'][$key] == 0) {
                $file_name = time() . "_" . basename($_FILES['dokumen_kepemilikan']['name'][$key]);
                move_uploaded_file($_FILES['dokumen_kepemilikan']['tmp_name'][$key], "uploads_dokumen/" . $file_name);
                $dokumen_files[] = $file_name;
            }
        }
    }
    $dokumen_json = json_encode($dokumen_files);

    // Simpan ke database
    $sql = "INSERT INTO motor (pemilik_id, merk, tipe_cc, plat_nomor, photo, dokumen_kepemilikan, status) 
            VALUES ('$pemilik_id','$merk','$tipe_cc','$plat_nomor','$photo','$dokumen_json','$status')";

    if ($conn->query($sql)) {
        header("Location: motor.php");
        exit;
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Motor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background:#f0f2f5;
            padding:20px;
        }
        .container {
            max-width:550px;
            margin:auto;
            background:white;
            padding:25px;
            border-radius:10px;
            box-shadow:0 2px 6px rgba(0,0,0,0.15);
        }
        h2 {
            text-align:center;
            margin-bottom:20px;
            color:#333;
        }
        label {
            font-weight:bold;
            display:block;
            margin-bottom:5px;
            color:#444;
        }
        input, select {
            width:100%;
            padding:10px;
            margin-bottom:15px;
            border:1px solid #ccc;
            border-radius:6px;
            font-size:14px;
        }
        button {
            width:100%;
            padding:12px;
            background:#007bff;
            border:none;
            border-radius:6px;
            color:white;
            font-size:16px;
            cursor:pointer;
        }
        button:hover {
            background:#0056b3;
        }
        .back {
            display:block;
            text-align:center;
            margin-top:10px;
            text-decoration:none;
            color:#555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>➕ Tambah Motor</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <label>Pemilik:</label>
            <select name="pemilik_id" required>
                <option value="">Pilih Pemilik</option>
                <?php while ($row = $pemilik->fetch_assoc()): ?>
                    <option value="<?= $row['id']; ?>"><?= $row['nama']; ?></option>
                <?php endwhile; ?>
            </select>

            <label>Merk:</label>
            <input type="text" name="merk" required>

            <label>Tipe CC:</label>
            <select name="tipe_cc" required>
                <option value="100">100 cc</option>
                <option value="125">125 cc</option>
                <option value="150">150 cc</option>
            </select>

            <label>Plat Nomor:</label>
            <input type="text" name="plat_nomor" required>

            <label>Foto Motor:</label>
            <input type="file" name="photo" required>

            <label>Dokumen Kepemilikan:</label>
            <input type="file" name="dokumen_kepemilikan[]" multiple required>

            <label>Status:</label>
            <select name="status" required>
                <option value="tersedia">Tersedia</option>
                <option value="disewa">Disewa</option>
                <option value="perawatan">Perawatan</option>
            </select>

            <button type="submit" name="submit">💾 Simpan</button>
            <a href="motor.php" class="back">⬅ Batal </a>
        </form>
    </div>
</body>
</html>