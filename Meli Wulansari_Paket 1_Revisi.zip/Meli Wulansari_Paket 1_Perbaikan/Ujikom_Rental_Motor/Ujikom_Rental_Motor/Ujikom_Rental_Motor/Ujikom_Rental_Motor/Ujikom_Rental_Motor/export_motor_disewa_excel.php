<?php
include "koneksi.php";

// Header untuk Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_motor_disewa.xls");

// Query data
$sql = "SELECT s.id, u.nama AS penyewa, u2.nama AS pemilik,
               CONCAT(m.merk, ' ', m.tipe_cc) AS motor,
               s.tanggal_mulai, s.tanggal_selesai, s.status
        FROM sewa s
        JOIN users u ON s.penyewa_id = u.id
        JOIN motor m ON s.motor_id = m.id
        JOIN users u2 ON m.pemilik_id = u2.id
        ORDER BY s.id DESC";
$result = $conn->query($sql);

// Cetak tabel
echo "<table border='1'>
<tr>
    <th>No</th>
    <th>Penyewa</th>
    <th>Pemilik</th>
    <th>Motor</th>
    <th>Tanggal Mulai</th>
    <th>Tanggal Selesai</th>
    <th>Status</th>
</tr>";
$no=1;
while($row = $result->fetch_assoc()){
    echo "<tr>
        <td>{$no}</td>
        <td>{$row['penyewa']}</td>
        <td>{$row['pemilik']}</td>
        <td>{$row['motor']}</td>
        <td>".($row['tanggal_mulai']!="0000-00-00"?date("d-m-Y", strtotime($row['tanggal_mulai'])):"-")."</td>
        <td>".($row['tanggal_selesai']!="0000-00-00"?date("d-m-Y", strtotime($row['tanggal_selesai'])):"-")."</td>
        <td>{$row['status']}</td>
    </tr>";
    $no++;
}
echo "</table>";
?>
