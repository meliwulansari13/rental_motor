<?php
session_start();
include "koneksi.php";

// Cek login & role penyewa
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'penyewa') {
    header("Location: login.php");
    exit();
}

$id_penyewa = intval($_SESSION['user_id']);

// Ambil data penyewa
$data_penyewa = $conn->query("SELECT * FROM users WHERE id='$id_penyewa'")->fetch_assoc();

// Hitung total sewa
$total_sewa = $conn->query("SELECT COUNT(*) AS total FROM sewa WHERE penyewa_id='$id_penyewa'")->fetch_assoc()['total'];

// Ambil 5 riwayat terakhir dengan perhitungan lama sewa & total harga
$riwayat = $conn->query("
    SELECT s.*, m.merk, m.plat_nomor, s.tipe_durasi,
           CASE s.tipe_durasi
               WHEN 'harian' THEN COALESCE(tarif.tarif_harian,0)
               WHEN 'mingguan' THEN COALESCE(tarif.tarif_mingguan,0)
               WHEN 'bulanan' THEN COALESCE(tarif.tarif_bulanan,0)
           END AS harga_satuan,
           GREATEST(DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1,1) AS lama_sewa,
           GREATEST(DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1,1) *
           CASE s.tipe_durasi
               WHEN 'harian' THEN COALESCE(tarif.tarif_harian,0)
               WHEN 'mingguan' THEN COALESCE(tarif.tarif_mingguan,0)
               WHEN 'bulanan' THEN COALESCE(tarif.tarif_bulanan,0)
           END AS total_harga
    FROM sewa s
    JOIN motor m ON s.motor_id = m.id
    LEFT JOIN (
        SELECT motor_id,
               MAX(CASE WHEN jenis='harian' THEN harga END) AS tarif_harian,
               MAX(CASE WHEN jenis='mingguan' THEN harga END) AS tarif_mingguan,
               MAX(CASE WHEN jenis='bulanan' THEN harga END) AS tarif_bulanan
        FROM tarif
        WHERE status='aktif'
        GROUP BY motor_id
    ) tarif ON tarif.motor_id = m.id
    WHERE s.penyewa_id='$id_penyewa'
    ORDER BY s.tanggal_mulai DESC
    LIMIT 5
");

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Penyewa</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { margin:0; font-family:'Segoe UI', Tahoma, sans-serif; background:#f4f6f9; }
.sidebar {
    width:230px;
    background:#000305ff;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    color:white;
    display:flex;
    flex-direction:column;
}
.sidebar h2 {
    text-align:center;
    padding:20px;
    margin:0;
    font-size:20px;
    font-weight:bold;
    background:#1a252f;
    color:#f8f7f5ff;
    letter-spacing:1px;
    border-bottom:2px solid #e9eef1ff;
}
.sidebar a {
    display:block;
    padding:14px 20px;
    color:#cfd8dc;
    text-decoration:none;
    font-size:14px;
    border-left:4px solid transparent;
    transition:0.3s;
}
.sidebar a:hover, .sidebar a.active {
    background:#0b0c0cff;
    color:#fff;
    border-left:4px solid #e7edf1ff;
}

.topbar {
    margin-left:230px;
    background:linear-gradient(90deg,#2980b9,#8e44ad);
    padding:15px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    position:sticky;
    top:0;
    z-index:10;
}
.topbar h1 { margin:0; font-size:22px; font-weight:bold; }

.dropdown { position:relative; display:inline-block; }
.dropbtn { background:transparent; border:none; color:white; font-size:14px; cursor:pointer; padding:8px 12px; border-radius:6px; }
.dropbtn:hover { background:rgba(255,255,255,0.1); }
.dropdown-content { display:none; position:absolute; right:0; background:#fff; min-width:200px; box-shadow:0px 8px 16px rgba(0,0,0,0.2); border-radius:8px; overflow:hidden; z-index:99; }
.dropdown-content a { color:#333; padding:10px 15px; text-decoration:none; display:block; font-size:14px; transition:0.2s; }
.dropdown-content a:hover { background:#f1f1f1; }
.show { display:block; }

.main { margin-left:230px; padding:20px; }
.cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:20px; margin-bottom:20px; }
.card {
    background:#fff;
    border-radius:12px;
    padding:20px;
    display:flex;
    align-items:center;
    gap:15px;
    text-decoration:none;
    color:inherit;
    transition: transform 0.2s, box-shadow 0.2s;
    cursor:pointer;
}
.card:hover { transform:translateY(-4px); box-shadow:0 6px 12px rgba(0,0,0,0.15); }
.icon { font-size:28px; padding:18px; border-radius:50%; color:#fff; }
.blue { background:#3498db; }
.green{ background:#27ae60; }
.orange{ background:#e67e22; }
.purple{ background:#9b59b6; }

.card-content h3 { margin:0; font-size:22px; font-weight:bold; color:#2c3e50; }
.card-content p { margin:5px 0 0; font-size:13px; color:#7f8c8d; }

.table-box { background:#fff; border-radius:12px; padding:20px; box-shadow:0 3px 8px rgba(0,0,0,0.08);}
table { width:100%; border-collapse:collapse; margin-top:15px; }
th, td { padding:12px; text-align:center; font-size:14px; border-bottom:1px solid #eee;}
th { background:#34495e; color:white; }
tr:hover { background:#f9f9f9; }
.status { padding:4px 8px; border-radius:5px; font-size:12px; font-weight:bold;}
.aktif { background:#f39c12; color:white; }
.selesai { background:#27ae60; color:white; }
.dibatalkan { background:#e74c3c; color:white; }

@media(max-width:768px){ .sidebar { width:200px; } .topbar, .main { margin-left:200px; } }
@media(max-width:576px){ .sidebar { position:absolute; left:-230px; } .sidebar.active { left:0; } .topbar, .main { margin-left:0; } }
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_penyewa.php" class="active"><i class="fa fa-home"></i> Dashboard</a>
    <a href="sewa_penyewa.php"><i class="fa fa-motorcycle"></i> Data Penyewaan</a>
    <a href="generate_riwayat_penyewaan_penyewa.php"><i class="fa fa-list"></i> Riwayat Penyewaan</a>
</div>


<!-- Topbar -->
<div class="topbar">
    <h1>Dashboard Penyewa</h1>
    <div class="user">
        <div class="dropdown">
            <button class="dropbtn" onclick="toggleDropdown()">
                <i class="fa fa-user-circle"></i> <?= htmlspecialchars($data_penyewa['nama']) ?> <i class="fa fa-caret-down"></i>
            </button>
            <div id="dropdownMenu" class="dropdown-content">
                <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="main">
    <div class="cards">
        <a href="profile.php" class="card">
            <div class="icon blue"><i class="fa fa-user"></i></div>
            <div class="card-content">
                <h3><?= htmlspecialchars($data_penyewa['nama']) ?></h3>
                <p>Nama Penyewa</p>
            </div>
        </a>
        <a href="sewa_penyewa.php" class="card">
            <div class="icon green"><i class="fa fa-envelope"></i></div>
            <div class="card-content">
                <h3><?= htmlspecialchars($data_penyewa['email']) ?></h3>
                <p>Detail sewa motor</p>
            </div>
        </a>
        <a href="generate_riwayat_penyewaan_penyewa.php" class="card">
            <div class="icon orange"><i class="fa fa-calendar-check"></i></div>
            <div class="card-content">
                <h3><?= $total_sewa ?></h3>
                <p>Riwayat Penyewaan</p>
            </div>
        </a>
    </div>

    <div class="table-box">
        <h3>Riwayat Sewa Terakhir</h3>
        <table>
    <tr>
        <th>No</th>
        <th>Motor</th>
        <th>Plat Nomor</th>
        <th>Durasi</th>
        <th>Tanggal Mulai</th>
        <th>Tanggal Selesai</th>
        <th>Lama Sewa (hari)</th>
        <th>Total Harga</th>
        <th>Status</th>
    </tr>
    <?php if($riwayat->num_rows > 0): 
        $no = 1;
        while($row = $riwayat->fetch_assoc()):
            $status_class = strtolower($row['status']);
    ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= htmlspecialchars($row['merk']) ?></td>
        <td><?= htmlspecialchars($row['plat_nomor']) ?></td>
        <td><?= ucfirst($row['tipe_durasi']) ?></td>
        <td><?= htmlspecialchars($row['tanggal_mulai']) ?></td>
        <td><?= htmlspecialchars($row['tanggal_selesai']) ?></td>
        <td><?= $row['lama_sewa'] ?></td>
        <td>Rp <?= number_format($row['total_harga'],0,',','.') ?></td>
        <td><span class="status <?= $status_class ?>"><?= ucfirst($row['status']) ?></span></td>
    </tr>
    <?php endwhile; else: ?>
    <tr><td colspan="9" style="text-align:center;">Belum ada riwayat sewa</td></tr>
    <?php endif; ?>
</table>
    </div>
</div>

<!-- Footer Pemilik -->
<div style="margin-left:230px; padding:10px 20px; text-align:center; color:#555; font-size:13px;">
    © <?= date('Y'); ?> Meli Wulansari – Rental Motor
</div>

<script>
function toggleDropdown() {
    document.getElementById("dropdownMenu").classList.toggle("show");
}
window.onclick = function(e) {
    if (!e.target.matches('.dropbtn') && !e.target.closest('.dropbtn')) {
        let dropdowns = document.getElementsByClassName("dropdown-content");
        for (let i = 0; i < dropdowns.length; i++) {
            dropdowns[i].classList.remove("show");
        }
    }
}
</script>
</body>
</html>