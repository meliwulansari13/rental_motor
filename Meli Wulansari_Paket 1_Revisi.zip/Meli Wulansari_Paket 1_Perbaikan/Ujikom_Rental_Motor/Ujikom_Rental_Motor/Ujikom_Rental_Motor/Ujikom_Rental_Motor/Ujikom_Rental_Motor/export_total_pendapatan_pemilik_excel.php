<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

$id_pemilik = $_SESSION['user_id'];
$periode = isset($_GET['periode']) ? $_GET['periode'] : 'bulan';

// Query sama seperti PDF
switch($periode){
    case 'hari':
        $sql = "SELECT DATE(s.tanggal_selesai) AS periode, SUM(s.total_harga) AS total
                FROM sewa s
                JOIN motor m ON s.motor_id = m.id
                WHERE m.pemilik_id = ? AND s.status='selesai'
                GROUP BY DATE(s.tanggal_selesai)
                ORDER BY DATE(s.tanggal_selesai) DESC";
        break;
    case 'minggu':
        $sql = "SELECT YEAR(s.tanggal_selesai) AS tahun, WEEK(s.tanggal_selesai,1) AS minggu, 
                       SUM(s.total_harga) AS total
                FROM sewa s
                JOIN motor m ON s.motor_id = m.id
                WHERE m.pemilik_id = ? AND s.status='selesai'
                GROUP BY YEAR(s.tanggal_selesai), WEEK(s.tanggal_selesai,1)
                ORDER BY YEAR(s.tanggal_selesai) DESC, WEEK(s.tanggal_selesai,1) DESC";
        break;
    case 'tahun':
        $sql = "SELECT YEAR(s.tanggal_selesai) AS periode, SUM(s.total_harga) AS total
                FROM sewa s
                JOIN motor m ON s.motor_id = m.id
                WHERE m.pemilik_id = ? AND s.status='selesai'
                GROUP BY YEAR(s.tanggal_selesai)
                ORDER BY YEAR(s.tanggal_selesai) DESC";
        break;
    default: // bulan
        $sql = "SELECT DATE_FORMAT(s.tanggal_selesai, '%Y-%m') AS periode, SUM(s.total_harga) AS total
                FROM sewa s
                JOIN motor m ON s.motor_id = m.id
                WHERE m.pemilik_id = ? AND s.status='selesai'
                GROUP BY DATE_FORMAT(s.tanggal_selesai, '%Y-%m')
                ORDER BY DATE_FORMAT(s.tanggal_selesai, '%Y-%m') DESC";
}

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_pemilik);
$stmt->execute();
$result = $stmt->get_result();
$pendapatan = [];
while($row = $result->fetch_assoc()){
    if($periode=='minggu') $row['periode'] = 'Tahun '.$row['tahun'].' - Minggu '.$row['minggu'];
    $pendapatan[] = $row;
}

// Total keseluruhan
$sql_total = "SELECT SUM(s.total_harga) AS total_keseluruhan
              FROM sewa s
              JOIN motor m ON s.motor_id = m.id
              WHERE m.pemilik_id = ? AND s.status='selesai'";
$stmt_total = $conn->prepare($sql_total);
$stmt_total->bind_param("i", $id_pemilik);
$stmt_total->execute();
$total_keseluruhan = $stmt_total->get_result()->fetch_assoc()['total_keseluruhan'] ?? 0;

// Export Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Total_Pendapatan_Pemilik.xls");

echo "<table border='1'>";
echo "<tr><th>No</th><th>Periode</th><th>Total Pendapatan (Rp)</th></tr>";

if(!empty($pendapatan)){
    foreach($pendapatan as $i => $p){
        echo "<tr>";
        echo "<td>".($i+1)."</td>";
        echo "<td>".$p['periode']."</td>";
        echo "<td>".number_format($p['total'],0,',','.')."</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='3'>Belum ada data pendapatan</td></tr>";
}

echo "<tr><th colspan='2'>Total Keseluruhan</th><th>".number_format($total_keseluruhan,0,',','.')."</th></tr>";
echo "</table>";
?>
