<?php
require('fpdf/fpdf.php');
include "koneksi.php";

// Ambil filter status dari URL (default Pending)
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'Pending';

// Query pembayaran + join sewa, motor, user
$sql = "
SELECT pb.id, u.nama AS penyewa, m.merk, m.plat_nomor,
       COALESCE((DATEDIFF(s.tanggal_selesai, s.tanggal_mulai)+1) * 
       COALESCE(s.total_harga, m.harga_sewa, 0),0) AS jumlah,
       IF(pb.status IS NULL OR pb.status='', 'Pending', pb.status) AS status,
       pb.tanggal_bayar
FROM pembayaran pb
JOIN sewa s ON pb.sewa_id = s.id
JOIN users u ON s.penyewa_id = u.id
JOIN motor m ON s.motor_id = m.id
WHERE IF(pb.status IS NULL OR pb.status='', 'Pending', pb.status) = ?
ORDER BY pb.tanggal_bayar ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $status_filter);
$stmt->execute();
$result = $stmt->get_result();

// Inisialisasi PDF
$pdf = new FPDF('L','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Laporan Konfirmasi Pembayaran',0,1,'C');
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,8,'Status: '.$status_filter,0,1,'C');
$pdf->Cell(0,8,'Tanggal Cetak: '.date('d-m-Y'),0,1,'C');
$pdf->Ln(5);

// Header tabel
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(200,200,200);
$pdf->Cell(10,8,'No',1,0,'C',true);
$pdf->Cell(50,8,'Penyewa',1,0,'C',true);
$pdf->Cell(60,8,'Motor',1,0,'C',true);
$pdf->Cell(40,8,'Tanggal Bayar',1,0,'C',true);
$pdf->Cell(40,8,'Jumlah (Rp)',1,0,'C',true);
$pdf->Cell(30,8,'Status',1,1,'C',true);

// Isi tabel
$pdf->SetFont('Arial','',10);
$i = 1;
$total_pembayaran = 0;
while($row = $result->fetch_assoc()){
    $pdf->Cell(10,8,$i++,1,0,'C');
    $pdf->Cell(50,8,$row['penyewa'],1,0);
    $pdf->Cell(60,8,$row['merk'].' ('.$row['plat_nomor'].')',1,0);
    $pdf->Cell(40,8,date('d-m-Y', strtotime($row['tanggal_bayar'])),1,0,'C');
    $pdf->Cell(40,8,number_format($row['jumlah'],0,',','.'),1,0,'R');
    $pdf->Cell(30,8,$row['status'],1,1,'C');
    $total_pembayaran += $row['jumlah'];
}

// Total pembayaran
$pdf->SetFont('Arial','B',10);
$pdf->Cell(160,8,'Total Pembayaran',1,0,'R',true);
$pdf->Cell(40,8,number_format($total_pembayaran,0,',','.'),1,1,'R',true);

// Output PDF
$pdf->Output('D','laporan_pembayaran_'.$status_filter.'.pdf');
