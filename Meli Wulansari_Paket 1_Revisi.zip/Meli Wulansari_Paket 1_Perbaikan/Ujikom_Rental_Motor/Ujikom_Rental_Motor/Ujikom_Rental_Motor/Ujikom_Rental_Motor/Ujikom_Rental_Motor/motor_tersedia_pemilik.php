<?php
session_start();
include "koneksi.php";

// Cek login & role pemilik
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'pemilik') {
    header("Location: login.php");
    exit();
}

$id_pemilik = $_SESSION['user_id'];

// Ambil semua motor milik pemilik, termasuk tarif terbaru per jenis
$query = "
SELECT m.id, m.merk, m.tipe_cc, m.plat_nomor, m.status, m.photo,
       t.tarif_harian, t.tarif_mingguan, t.tarif_bulanan
FROM motor m
LEFT JOIN (
    SELECT motor_id,
           MAX(CASE WHEN jenis='harian' THEN harga END) AS tarif_harian,
           MAX(CASE WHEN jenis='mingguan' THEN harga END) AS tarif_mingguan,
           MAX(CASE WHEN jenis='bulanan' THEN harga END) AS tarif_bulanan
    FROM tarif
    WHERE status='aktif'
    GROUP BY motor_id
) t ON t.motor_id = m.id
WHERE m.pemilik_id = ?
ORDER BY m.id ASC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_pemilik);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Motor Pemilik</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body { margin:0; font-family:'Segoe UI', sans-serif; background:#f4f6f9; }
.sidebar { width:220px; background:#111827; color:white; height:100vh; position:fixed; padding-top:20px; }
.sidebar h2 { text-align:center; margin-bottom:20px; font-size:18px; color:white; }
.sidebar a { display:block; color:white; padding:10px 20px; text-decoration:none; font-size:14px; }
.sidebar a:hover, .sidebar a.active { background:#2563eb; }
.main { margin-left:220px; padding:20px; min-height:100vh; }
.grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(250px, 1fr)); gap:20px; justify-items:center; }
.card { background:#fff; border-radius:12px; padding:10px; box-shadow:0 3px 8px rgba(0,0,0,0.1); transition: transform 0.2s, box-shadow 0.2s; display:flex; flex-direction:column; max-width:250px; width:100%; }
.card:hover { transform:translateY(-4px); box-shadow:0 6px 12px rgba(0,0,0,0.15); }
.card img { width:100%; height:140px; object-fit:cover; border-radius:10px; margin-bottom:10px; }
.card h3 { margin:0 0 10px; font-size:18px; color:#34495e; text-align:center; }
.card p { margin:4px 0; font-size:14px; color:#7f8c8d; text-align:center; }
.status { display:inline-block; padding:4px 10px; border-radius:6px; font-size:12px; font-weight:bold; color:#fff; }
.tersedia { background:#27ae60; }
.disewa { background:#e74c3c; }
.perawatan { background:#f39c12; }
.button { margin-top:10px; padding:6px 12px; background:#3498db; color:white; text-decoration:none; border-radius:6px; text-align:center; font-size:14px; display:inline-block; }
.button:hover { background:#2980b9; }
.back { grid-column:1/-1; text-align:center; margin-top:20px; }
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="dashboard_pemilik.php"><i class="fa fa-home"></i> Dashboard</a>
    <a href="motor_pemilik.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_tersedia_pemilik.php" class="active"><i class="fa fa-check-circle"></i> Motor Tersedia</a>
    <a href="generate_daftar_motor_disewa_pemilik.php"><i class="fa fa-list"></i> Motor Disewa</a>
    <a href="history_bagi_hasil_pemilik.php"><i class="fa fa-history"></i> Bagi Hasil</a>
    <a href="generate_total_pendapatan_pemilik.php"><i class="fa fa-chart-line"></i> Total Pendapatan</a>
</div>



<div class="main">
    <h1>Motor Milik Anda</h1>
    <div class="grid">
    <?php
    if ($result->num_rows > 0) {
        while ($motor = $result->fetch_assoc()) {
            $photoPath = (!empty($motor['photo']) && file_exists("uploads_motor/".$motor['photo'])) 
                         ? "uploads_motor/".$motor['photo'] 
                         : "https://via.placeholder.com/400x200?text=No+Image";

            $tarif_harian = $motor['tarif_harian'] ?? 0;
            $tarif_mingguan = $motor['tarif_mingguan'] ?? 0;
            $tarif_bulanan = $motor['tarif_bulanan'] ?? 0;

            // Tentukan class status
            $status_class = strtolower($motor['status']);
            ?>
            <div class="card">
                <img src="<?= htmlspecialchars($photoPath) ?>" alt="Motor">
                <h3><?= htmlspecialchars($motor['merk']) ?> (<?= htmlspecialchars($motor['tipe_cc']) ?> cc)</h3>
                <p><i class="fa fa-id-card"></i> Plat: <?= htmlspecialchars($motor['plat_nomor']) ?></p>
                <p>Status: <span class="status <?= $status_class ?>"><?= htmlspecialchars($motor['status']) ?></span></p>
                <p><i class="fa fa-money-bill-wave"></i> Tarif Harian: Rp <?= number_format($tarif_harian,0,',','.') ?></p>
                <p><i class="fa fa-money-bill-wave"></i> Tarif Mingguan: Rp <?= number_format($tarif_mingguan,0,',','.') ?></p>
                <p><i class="fa fa-money-bill-wave"></i> Tarif Bulanan: Rp <?= number_format($tarif_bulanan,0,',','.') ?></p>
                <a href="detail_motor.php?id=<?= $motor['id'] ?>" class="button"><i class="fa fa-info-circle"></i> Detail</a>
            </div>
            <?php
        }
    } else {
        echo "<p style='grid-column:1/-1; text-align:center;'>Tidak ada motor terdaftar.</p>";
    }
    ?>
    </div>

    <div class="back">
    </div>
</div>

</body>
</html>
