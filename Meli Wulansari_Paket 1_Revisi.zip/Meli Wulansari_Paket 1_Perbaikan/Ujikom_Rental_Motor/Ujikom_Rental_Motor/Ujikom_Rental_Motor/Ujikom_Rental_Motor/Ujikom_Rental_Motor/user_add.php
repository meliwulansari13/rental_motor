<?php
session_start();
include "koneksi.php";

// Cek login admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$error = "";
$success = "";

// Proses Tambah
if (isset($_POST['add'])) {
    $nama     = trim($_POST['nama']);
    $email    = trim($_POST['email']);
    $no_tlpn  = trim($_POST['no_tlpn']);
    $password = $_POST['password'];
    $role     = $_POST['role'];

    // Cek email unik
    $cek = $conn->query("SELECT id FROM users WHERE email='$email'");
    if ($cek->num_rows > 0) {
        $error = "❌ Email <b>$email</b> sudah dipakai, gunakan email lain.";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (nama, email, password, no_tlpn, role)
                VALUES ('$nama', '$email', '$hashedPassword', '$no_tlpn', '$role')";
        if ($conn->query($sql)) {
            $success = "✅ User berhasil ditambahkan.";
        } else {
            $error = "Terjadi kesalahan: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah User</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }
        .container {
            background: #fff;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 6px 15px rgba(0,0,0,0.15);
            width: 400px;
        }
        h2 {
            text-align: center;
            margin-top: 0;
            color: #333;
        }
        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #7f8c8d;
            text-decoration: none;
            font-size: 14px;
        }
        .back:hover { text-decoration: underline; }
        .form-group { margin-bottom: 15px; }
        .form-group input, 
        .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: border 0.2s;
        }
        .form-group input:focus, 
        .form-group select:focus {
            border-color: #3498db;
        }
        button {
            width: 100%;
            padding: 10px;
            background: #2ecc71;
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover { background: #27ae60; }
        .alert {
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .error { background: #fdecea; color: #e74c3c; }
        .success { background: #e8f9f0; color: #27ae60; }
    </style>
</head>
<body>
    <div class="container">
        <a href="users.php" class="back"><i class="fa fa-arrow-left"></i> Kembali</a>
        <h2>Tambah User</h2>

        <?php if ($error): ?>
            <div class="alert error"><?= $error; ?></div>
        <?php elseif ($success): ?>
            <div class="alert success"><?= $success; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <input type="text" name="nama" placeholder="Nama Lengkap" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="text" name="no_tlpn" placeholder="No Telepon">
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="form-group">
                <select name="role" required>
                    <option value=""> Pilih Role </option>
                    <option value="pemilik">Pemilik</option>
                    <option value="penyewa">Penyewa</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <button type="submit" name="add"><i class="fa fa-save"></i> Simpan</button>
        </form>
    </div>
</body>
</html>
