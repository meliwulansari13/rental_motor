<?php
session_start();
include "koneksi.php";

// cek login & role admin atau pemilik
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin','pemilik'])) {
    header("Location: login.php");
    exit();
}

// ambil id motor dari URL
$motor_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($motor_id <= 0) {
    $redirect = ($_SESSION['role'] == 'admin') ? "dashboard_admin.php" : "dashboard_pemilik.php";
    header("Location: $redirect");
    exit();
}

// ambil data motor + tarif terbaru dari tabel tarif
$stmt = $conn->prepare("
    SELECT m.*, u.nama AS pemilik,
           COALESCE(t.harga, m.harga_sewa) AS tarif_terbaru
    FROM motor m
    JOIN users u ON m.pemilik_id = u.id
    LEFT JOIN (
        SELECT motor_id, MAX(harga) AS harga
        FROM tarif
        WHERE status='aktif'
        GROUP BY motor_id
    ) t ON t.motor_id = m.id
    WHERE m.id=?
");
$stmt->bind_param("i", $motor_id);
$stmt->execute();
$motor = $stmt->get_result()->fetch_assoc();
if (!$motor) {
    echo "Motor tidak ditemukan!";
    exit();
}

// ambil histori sewa motor
$histori = $conn->prepare("
    SELECT s.*, u.nama AS penyewa 
    FROM sewa s 
    JOIN users u ON s.penyewa_id = u.id 
    WHERE s.motor_id=? 
    ORDER BY s.tanggal_mulai DESC
");
$histori->bind_param("i", $motor_id);
$histori->execute();
$histori_result = $histori->get_result();

// fungsi badge warna status
function badgeStatus($status){
    switch(strtolower($status)){
        case 'tersedia': return '<span style="color:#fff;background:#27ae60;padding:4px 8px;border-radius:6px;">Tersedia</span>';
        case 'disewa': return '<span style="color:#fff;background:#e67e22;padding:4px 8px;border-radius:6px;">Disewa</span>';
        case 'perbaikan': return '<span style="color:#fff;background:#c0392b;padding:4px 8px;border-radius:6px;">Perbaikan</span>';
        default: return '<span style="color:#fff;background:#7f8c8d;padding:4px 8px;border-radius:6px;">'.htmlspecialchars($status).'</span>';
    }
}

// tombol kembali sesuai role
$backUrl = ($_SESSION['role'] == 'admin') ? "dashboard_admin.php" : "dashboard_pemilik.php";
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Detail Motor</title>
<style>
body {font-family:Segoe UI,sans-serif;background:#f4f6f9;margin:0;padding:20px;}
.container {max-width:900px;margin:auto;background:#fff;padding:20px;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.1);}
h2 {text-align:center;color:#2c3e50;margin-bottom:20px;}
.motor-info {display:flex;gap:20px;margin-bottom:20px;flex-wrap:wrap;}
.motor-info img {width:300px;height:180px;object-fit:cover;border-radius:10px;}
.motor-details {flex:1;}
.motor-details p {margin:5px 0;font-size:15px;}
.table {width:100%;border-collapse:collapse;margin-top:15px;}
.table th, .table td {border:1px solid #ddd;padding:8px;text-align:center;font-size:14px;}
.table th {background:#34495e;color:#fff;}
.table tr:nth-child(even){background:#fafafa;}
.table tr:hover{background:#f1f1f1;}
.btn-back {display:inline-block;margin-top:15px;padding:10px 18px;background:#2980b9;color:#fff;border-radius:6px;text-decoration:none;font-weight:bold;}
.btn-back:hover {background:#1f6391;}
</style>
</head>
<body>
<div class="container">
<h2>Detail Motor</h2>
<div class="motor-info">
    <img src="<?= !empty($motor['photo']) && file_exists("uploads_motor/".$motor['photo']) ? 'uploads_motor/' . htmlspecialchars($motor['photo']) : 'https://via.placeholder.com/300x180?text=No+Image'; ?>" alt="Foto Motor">
    <div class="motor-details">
        <p><strong>Merk:</strong> <?= htmlspecialchars($motor['merk']) ?></p>
        <p><strong>Tipe:</strong> <?= htmlspecialchars($motor['tipe_cc']) ?></p>
        <p><strong>Plat Nomor:</strong> <?= htmlspecialchars($motor['plat_nomor']) ?></p>
        <p><strong>Status:</strong> <?= badgeStatus($motor['status']) ?></p>
        <p><strong>Verifikasi:</strong> <?= htmlspecialchars($motor['verifikasi']) ?></p>
        <p><strong>Pemilik:</strong> <?= htmlspecialchars($motor['pemilik']) ?></p>
        <p><strong>Tarif Sewa:</strong> Rp <?= number_format($motor['tarif_terbaru'],0,',','.') ?></p>
    </div>
</div>

<h3>📜 Histori Sewa</h3>
<?php if($histori_result->num_rows>0): ?>
<table class="table">
<tr>
    <th>No</th>
    <th>Penyewa</th>
    <th>Tanggal Mulai</th>
    <th>Tanggal Selesai</th>
    <th>Status</th>
</tr>
<?php $no=1; while($row=$histori_result->fetch_assoc()): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= htmlspecialchars($row['penyewa']) ?></td>
    <td><?= $row['tanggal_mulai'] ?></td>
    <td><?= $row['tanggal_selesai'] ?></td>
    <td><?= badgeStatus($row['status']) ?></td>
</tr>
<?php endwhile; ?>
</table>
<?php else: ?>
<p style="text-align:center;color:#7f8c8d;font-weight:bold;">Belum ada histori sewa untuk motor ini.</p>
<?php endif; ?>

<a href="<?= $backUrl ?>" class="btn-back">⬅ Kembali</a>
</div>
</body>
</html>
