<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

include "koneksi.php";

// Cek ID sewa
if (!isset($_GET['id'])) {
    header("Location: sewa.php");
    exit;
}

$id = (int)$_GET['id'];

// Ambil data untuk validasi
$cek = $conn->prepare("SELECT id FROM sewa WHERE id=?");
$cek->bind_param("i", $id);
$cek->execute();
$res = $cek->get_result();

if ($res->num_rows == 0) {
    $_SESSION['msg'] = "Data penyewaan tidak ditemukan!";
    header("Location: sewa.php");
    exit;
}

// Hapus data
$del = $conn->prepare("DELETE FROM sewa WHERE id=?");
$del->bind_param("i", $id);

if ($del->execute()) {
    $_SESSION['msg'] = "Data penyewaan berhasil dihapus.";
} else {
    $_SESSION['msg'] = "Gagal menghapus data penyewaan!";
}

header("Location: sewa.php");
exit;
