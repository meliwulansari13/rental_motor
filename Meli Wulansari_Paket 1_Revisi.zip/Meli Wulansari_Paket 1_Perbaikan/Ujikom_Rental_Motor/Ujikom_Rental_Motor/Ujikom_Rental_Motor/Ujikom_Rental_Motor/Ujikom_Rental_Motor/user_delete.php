<?php
session_start();
include "koneksi.php";

// Cek login admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Ambil data user dulu biar tahu siapa yang mau dihapus
    $user = $conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc();

    if (!$user) {
        echo "<p>User tidak ditemukan!</p>";
        echo "<a href='users.php'>⬅ Kembali</a>";
        exit();
    }

    // Kalau ada tombol hapus ditekan
    if (isset($_POST['confirm_delete'])) {
        $conn->query("DELETE FROM users WHERE id=$id");
        header("Location: users.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hapus User</title>
    <style>
        body { font-family: Arial, sans-serif; background:#f9f9f9; padding:30px; }
        .box {
            background:white;
            padding:20px;
            border-radius:8px;
            max-width:400px;
            margin:auto;
            text-align:center;
            box-shadow:0 0 10px rgba(0,0,0,0.1);
        }
        button {
            padding:8px 15px;
            border:none;
            border-radius:5px;
            cursor:pointer;
            margin:5px;
        }
        .yes { background:#e74c3c; color:white; }
        .no { background:#3498db; color:white; text-decoration:none; padding:8px 15px; border-radius:5px; }
    </style>
</head>
<body>
    <div class="box">
        <h2>⚠️ Konfirmasi Hapus</h2>
        <p>Apakah Anda yakin ingin menghapus user <b><?= htmlspecialchars($user['nama']); ?></b>?</p>

        <form method="POST">
            <button type="submit" name="confirm_delete" class="yes">Ya, Hapus</button>
            <a href="users.php" class="no">Batal</a>
        </form>
    </div>
</body>
</html>
