<?php
session_start();
include "koneksi.php";

// Cek login & role admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Pencarian
$search = "";
$params = [];
$search_sql = "";

if (isset($_GET['search']) && trim($_GET['search']) !== "") {
    $search = "%" . trim($_GET['search']) . "%";
    $search_sql = " WHERE u.nama LIKE ? 
              OR m.merk LIKE ? 
              OR m.tipe_cc LIKE ? 
              OR m.plat_nomor LIKE ? 
              OR m.status LIKE ? 
              OR m.verifikasi LIKE ?";
    $params = [$search, $search, $search, $search, $search, $search];
}

// DATA QUERY (tanpa limit & offset)
$sql = "SELECT m.*, u.nama AS nama_pemilik 
        FROM motor m
        LEFT JOIN users u ON m.pemilik_id = u.id" .
        $search_sql .
        " ORDER BY m.id ASC";

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$motors = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Motor - Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* RESET & BODY */
body, html { margin:0; padding:0; font-family:'Segoe UI', Tahoma, sans-serif; background:#f1f3f6; }

/* SIDEBAR */
.sidebar {
    position: fixed;
    top: 0; left: 0;
    width: 220px;
    height: 100%;
    background: #080808ff;
    color: white;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
}
.sidebar h2 {
    text-align:center; padding:20px 0;
    border-bottom:1px solid rgba(255,255,255,0.2);
    margin:0;
}
.sidebar a {
    padding:15px 20px;
    text-decoration:none;
    color:white;
    display:block;
    border-bottom:1px solid rgba(255,255,255,0.1);
}
.sidebar a:hover { background:#34495e; }

/* MAIN CONTENT */
.main {
    margin-left: 220px;
    padding: 20px;
}

/* Top actions */
.actions-top {
    display:flex;
    justify-content: flex-start;
    flex-wrap: wrap;
    gap:10px;
    margin-bottom:20px;
}
.actions-top a, .actions-top button {
    padding:7px 12px;
    border-radius:6px;
    border:none;
    text-decoration:none;
    color:white;
    cursor:pointer;
    font-size:14px;
}
.btn-add { background:#2ecc71; } .btn-add:hover { background:#27ae60; }
.btn-refresh { background:#f39c12; } .btn-refresh:hover { background:#e67e22; }

/* Card grid */
.card-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

/* Card */
.card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    padding: 15px;
    display: flex;
    flex-direction: column;
    align-items: center;
    transition: transform 0.2s;
}
.card:hover { transform: translateY(-5px); }
.card img { width: 100%; height: 150px; object-fit: cover; border-radius: 8px; margin-bottom: 10px; }
.card .info { text-align: center; margin-bottom: 10px; font-size: 14px; }
.card .info b { display:block; margin-bottom: 4px; }

/* Badges */
.badge { padding: 3px 8px; border-radius: 6px; font-size: 12px; display:inline-block; margin:2px 0; }
.green { background:#2ecc71; color:white; }
.red { background:#e74c3c; color:white; }
.orange { background:#f39c12; color:white; }

/* Card actions */
.card .actions { display: flex; gap: 5px; flex-wrap: wrap; justify-content: center; margin-top: 5px; }
.card .actions a { font-size: 12px; padding:4px 6px; border-radius:6px; text-decoration: none; color:white; }
.edit { background:#2980b9; } .hapus { background:#e74c3c; }
.verif-yes { background:#2ecc71; } .verif-no { background:#f39c12; }

/* SEARCH */
.search-form { margin-bottom: 15px; }
.search-form input[type="text"] { padding:6px 10px; border-radius:5px; border:1px solid #ccc; width:200px; }
.search-form button { padding:6px 10px; border:none; border-radius:5px; background:#2980b9; color:white; cursor:pointer; }
</style>
</head>
<body>

<div class="sidebar">
    <h2>RENTAL MOTOR</h2>
    <a href="users.php"><i class="fa fa-users"></i> Data User</a>
    <a href="motor.php"><i class="fa fa-motorcycle"></i> Data Motor</a>
    <a href="motor_verifikasi.php"><i class="fa fa-hourglass-half"></i> Motor Verifikasi</a>
    <a href="konfirmasi_pengembalian.php"><i class="fa fa-hourglass-half"></i> Motor Pengembalian</a>
    <a href="konfirmasi_pembayaran_motor.php"><i class="fa fa-hourglass-half"></i> Konfirmasi Pembayaran</a>
    <a href="motor_tersedia.php"><i class="fa fa-hourglass-half"></i> Motor Tersedia</a>
    <a href="tarif.php"><i class="fa fa-tags"></i> Data Tarif Rental</a>
    <a href="sewa.php"><i class="fa fa-file-contract"></i> Data Penyewaan</a>
    <a href="pembayaran.php"><i class="fa fa-credit-card"></i> Data Pembayaran</a>
    <a href="transaksi.php"><i class="fa fa-exchange-alt"></i> Entri Transaksi</a>
    <a href="history_bagi_hasil.php"><i class="fa fa-history"></i> History Bagi Hasil</a>
    <a href="grafik_per_periode.php"><i class="fa fa-chart-line"></i> Grafik Per Periode</a>
    <a href="generate_riwayat_penyewaan_admin.php"><i class="fa fa-file-alt"></i> Riwayat Penyewaan</a>
    <a href="generate_daftar_motor_terdaftar_admin.php"><i class="fa fa-list"></i> Daftar Motor Terdaftar</a>
    <a href="generate_daftar_motor_disewa_admin.php"><i class="fa fa-list-check"></i> Daftar Motor Disewa</a>
    <a href="generate_total_pendapatan_admin.php"><i class="fa fa-money-bill"></i> Total Pendapatan</a>
    <a href="generate_Laporan_pembayaran.php"><i class="fa fa-file-invoice"></i> Laporan</a>
    <a href="logout.php"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>


<div class="main">
    <form method="get" class="search-form">
        <input type="text" name="search" placeholder="Cari motor..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button type="submit"><i class="fa fa-search"></i> Cari</button>
    </form>

    <div class="actions-top">
        <a href="motor.php" class="btn-refresh"><i class="fa fa-sync-alt"></i> Refresh</a>
    </div>

    <div class="card-container">
        <?php if ($motors->num_rows > 0): ?>
            <?php while($row = $motors->fetch_assoc()): ?>
                <div class="card">
                    <?php if ($row['photo']): ?>
                        <img src="uploads_motor/<?= $row['photo']; ?>" alt="<?= $row['merk']; ?>">
                    <?php endif; ?>
                    <div class="info">
                        <b><?= $row['merk']; ?> <?= $row['tipe_cc']; ?> cc</b>
                        <span>Pemilik: <?= $row['nama_pemilik']; ?></span><br>
                        <span>Plat: <?= $row['plat_nomor']; ?></span><br>
                        <span>Status: <?= ucfirst($row['status']); ?></span><br>
                        <?php 
                            if ($row['verifikasi'] == 'diterima') echo "<span class='badge green'>Diterima</span>";
                            elseif ($row['verifikasi'] == 'ditolak') echo "<span class='badge red'>Ditolak</span>";
                            else echo "<span class='badge orange'>Pending</span>";
                        ?>
                    </div>
                    <?php 
                    $dokumen = json_decode($row['dokumen_kepemilikan'], true);
                    if ($dokumen): ?>
                        <div class="info">
                            <?php foreach($dokumen as $file): ?>
                                <a href="uploads_dokumen/<?= $file; ?>" target="_blank">📄 <?= $file; ?></a><br>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <div class="actions">
                        <a href="motor_edit.php?id=<?= $row['id']; ?>" class="edit"><i class="fa fa-edit"></i></a>
                        <a href="motor_delete.php?id=<?= $row['id']; ?>" class="hapus" onclick="return confirm('Yakin hapus motor ini?');"><i class="fa fa-trash"></i></a>
                        <?php if ($row['verifikasi'] == 'pending'): ?>
                            <a href="motor_verifikasi.php?id=<?= $row['id']; ?>&aksi=diterima" class="verif-yes"><i class="fa fa-check"></i></a>
                            <a href="motor_verifikasi.php?id=<?= $row['id']; ?>&aksi=ditolak" class="verif-no"><i class="fa fa-times"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>Tidak ada data ditemukan.</p>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
