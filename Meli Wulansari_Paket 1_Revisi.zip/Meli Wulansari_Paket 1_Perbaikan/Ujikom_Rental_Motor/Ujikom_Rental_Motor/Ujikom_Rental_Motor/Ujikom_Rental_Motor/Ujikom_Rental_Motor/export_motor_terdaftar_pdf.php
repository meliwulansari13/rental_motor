<?php
require('fpdf/fpdf.php');
include "koneksi.php";

// Ambil semua motor terdaftar
$sql = "SELECT id, merk, tipe_cc, plat_nomor, status, harga_sewa 
        FROM motor
        ORDER BY merk ASC";
$result = $conn->query($sql);

// Inisialisasi PDF
$pdf = new FPDF('L','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Daftar Motor Terdaftar',0,1,'C');
$pdf->Ln(5);

// Header tabel
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(200,200,200);
$pdf->Cell(10,8,'No',1,0,'C',true);
$pdf->Cell(60,8,'Merk',1,0,'C',true);
$pdf->Cell(50,8,'Tipe CC',1,0,'C',true);
$pdf->Cell(40,8,'Plat Nomor',1,0,'C',true);
$pdf->Cell(40,8,'Status',1,0,'C',true);
$pdf->Cell(40,8,'Harga Sewa (Rp)',1,1,'C',true);

// Isi tabel
$pdf->SetFont('Arial','',10);
$i = 1;
while($row = $result->fetch_assoc()){
    $pdf->Cell(10,8,$i++,1,0,'C');
    $pdf->Cell(60,8,$row['merk'],1,0);
    $pdf->Cell(50,8,$row['tipe_cc'],1,0,'C');
    $pdf->Cell(40,8,$row['plat_nomor'],1,0,'C');
    $pdf->Cell(40,8,$row['status'],1,0,'C');
    $pdf->Cell(40,8,number_format($row['harga_sewa'],0,',','.'),1,1,'R');
}

// Output PDF
$pdf->Output('D','motor_terdaftar.pdf');
